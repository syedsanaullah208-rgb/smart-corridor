
import '../../core/app_export.dart';
import './widgets/greeting_header_widget.dart';
import './widgets/home_metrics_row_widget.dart';
import './widgets/plan_progress_card_widget.dart';
import './widgets/unit_card_widget.dart';
import './widgets/weekday_strip_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production — home screen state
  int _navIndex = 0;
  int _selectedDayIndex = 3; // Thursday default
  late AnimationController _listController;
  late List<Animation<Offset>> _slideAnimations;
  late List<Animation<double>> _fadeAnimations;

  final List<Map<String, dynamic>> _unitMaps = [
    {
      'id': 'AMB-001',
      'name': 'Ambulance KA-01',
      'timeRange': '08:15 AM – Active',
      'status': 'enRoute',
      'role': 'Emergency Response',
      'rating': 4.8,
      'location': 'MG Road → Victoria Hospital',
      'eta': '4 min',
      'imageUrl':
          'https://images.unsplash.com/photo-1662046184222-68d8f7fa1861',
      'semanticLabel':
          'White ambulance vehicle with red cross markings on a city road',
    },
    {
      'id': 'AMB-003',
      'name': 'Ambulance KA-03',
      'timeRange': '09:45 AM – Active',
      'status': 'standby',
      'role': 'Trauma Unit',
      'rating': 4.6,
      'location': 'Indiranagar Station',
      'eta': 'On Standby',
      'imageUrl':
          'https://images.unsplash.com/photo-1710271961701-c9ef3c9336d1',
      'semanticLabel':
          'Modern ambulance parked at a medical station ready for dispatch',
    },
    {
      'id': 'POL-007',
      'name': 'Police Unit KA-07',
      'timeRange': '07:30 AM – Active',
      'status': 'active',
      'role': 'Traffic Control',
      'rating': 4.5,
      'location': 'Silk Board Junction',
      'eta': 'Deployed',
      'imageUrl':
          'https://images.unsplash.com/photo-1683645181232-51ec89d1077f',
      'semanticLabel':
          'Police patrol car with lights on stationed at a busy intersection',
    },
    {
      'id': 'AMB-009',
      'name': 'Ambulance KA-09',
      'timeRange': '10:20 AM – Active',
      'status': 'arrived',
      'role': 'ICU Transfer',
      'rating': 4.9,
      'location': 'Manipal Hospital',
      'eta': 'Arrived',
      'imageUrl':
          'https://img.rocket.new/generatedImages/rocket_gen_img_112bd1267-1772115878885.png',
      'semanticLabel':
          'Ambulance at hospital entrance with medical staff receiving patient',
    },
    {
      'id': 'POL-012',
      'name': 'Police Unit KA-12',
      'timeRange': '06:00 AM – Active',
      'status': 'enRoute',
      'role': 'Incident Response',
      'rating': 4.7,
      'location': 'Outer Ring Road → Whitefield',
      'eta': '7 min',
      'imageUrl':
          'https://images.unsplash.com/photo-1628795558740-69a19b9cecbb',
      'semanticLabel':
          'Police vehicle with emergency lights on responding to an incident on the highway',
    },
  ];

  List<_UnitModel> _units = [];

  @override
  void initState() {
    super.initState();
    _units = _unitMaps.map(_UnitModel.fromMap).toList();

    _listController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 350 + _units.length * 60),
    );

    _slideAnimations = List.generate(_units.length, (i) {
      final start = (i * 0.12).clamp(0.0, 0.7);
      final end = (start + 0.4).clamp(0.0, 1.0);
      return Tween<Offset>(
        begin: const Offset(0, 0.3),
        end: Offset.zero,
      ).animate(
        CurvedAnimation(
          parent: _listController,
          curve: Interval(start, end, curve: Curves.easeOutCubic),
        ),
      );
    });

    _fadeAnimations = List.generate(_units.length, (i) {
      final start = (i * 0.12).clamp(0.0, 0.7);
      final end = (start + 0.35).clamp(0.0, 1.0);
      return Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: _listController,
          curve: Interval(start, end, curve: Curves.easeOut),
        ),
      );
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _listController.forward();
    });
  }

  @override
  void dispose() {
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
      ),
      bottomNavigationBar: isTablet
          ? null
          : AppNavigation(
              currentIndex: _navIndex,
              onDestinationSelected: (i) => setState(() => _navIndex = i),
            ),
    );
  }

  Widget _buildPhoneLayout() {
    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: GreetingHeaderWidget(onNotificationTap: () {}),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: HomeMetricsRowWidget(),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 16)),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: PlanProgressCardWidget(),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildScheduleSection(),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildUnitsHeader(),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 12)),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) => _buildAnimatedUnitCard(index),
            childCount: _units.length,
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Row(
      children: [
        AppNavigation(
          currentIndex: _navIndex,
          onDestinationSelected: (i) => setState(() => _navIndex = i),
        ),
        Expanded(child: _buildPhoneLayout()),
        SizedBox(width: 320, child: _buildTabletSidebar()),
      ],
    );
  }

  Widget _buildTabletSidebar() {
    return Container(
      color: AppTheme.surfaceLight,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quick Actions',
            style: GoogleFonts.manrope(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 16),
          _buildQuickActionButton(
            'sos',
            'Trigger SOS',
            AppTheme.sosRed,
            Colors.white,
          ),
          const SizedBox(height: 10),
          _buildQuickActionButton(
            'traffic',
            'Signal Override',
            AppTheme.signalOverride,
            Colors.white,
          ),
          const SizedBox(height: 10),
          _buildQuickActionButton(
            'local_hospital',
            'Alert Hospital',
            AppTheme.secondary,
            Colors.white,
          ),
          const SizedBox(height: 10),
          _buildQuickActionButton(
            'campaign',
            'Broadcast Alert',
            AppTheme.warning,
            Colors.white,
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton(
    String icon,
    String label,
    Color bg,
    Color fg,
  ) {
    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(14),
      splashColor: bg.withAlpha(38),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        decoration: BoxDecoration(
          color: bg.withAlpha(26),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: bg.withAlpha(77), width: 1),
        ),
        child: Row(
          children: [
            CustomIconWidget(iconName: icon, color: bg, size: 20),
            const SizedBox(width: 10),
            Text(
              label,
              style: GoogleFonts.manrope(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: bg,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScheduleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Your Schedule',
              style: GoogleFonts.manrope(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
            ),
            Row(
              children: [
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'chevron_left',
                    color: AppTheme.textSecondary,
                    size: 18,
                  ),
                  onPressed: () {},
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(
                    minWidth: 28,
                    minHeight: 28,
                  ),
                ),
                Text(
                  'May 2026',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.textSecondary,
                  ),
                ),
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: AppTheme.textSecondary,
                    size: 18,
                  ),
                  onPressed: () {},
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(
                    minWidth: 28,
                    minHeight: 28,
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 12),
        WeekdayStripWidget(
          selectedIndex: _selectedDayIndex,
          onDaySelected: (i) => setState(() => _selectedDayIndex = i),
        ),
      ],
    );
  }

  Widget _buildUnitsHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Active Units',
          style: GoogleFonts.manrope(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
          ),
        ),
        InkWell(
          onTap: () {},
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Row(
              children: [
                Text(
                  'View All',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primary,
                  ),
                ),
                const SizedBox(width: 3),
                CustomIconWidget(
                  iconName: 'arrow_forward',
                  color: AppTheme.primary,
                  size: 12,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAnimatedUnitCard(int index) {
    return AnimatedBuilder(
      animation: _listController,
      builder: (context, child) {
        return SlideTransition(
          position: _slideAnimations[index],
          child: FadeTransition(opacity: _fadeAnimations[index], child: child),
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        child: UnitCardWidget(unit: _units[index]),
      ),
    );
  }
}

// ─── Model ───────────────────────────────────────────────────────────────────

class _UnitModel {
  final String id;
  final String name;
  final String timeRange;
  final String status;
  final String role;
  final double rating;
  final String location;
  final String eta;
  final String imageUrl;
  final String semanticLabel;

  _UnitModel({
    required this.id,
    required this.name,
    required this.timeRange,
    required this.status,
    required this.role,
    required this.rating,
    required this.location,
    required this.eta,
    required this.imageUrl,
    required this.semanticLabel,
  });

  factory _UnitModel.fromMap(Map<String, dynamic> map) => _UnitModel(
    id: map['id'] as String,
    name: map['name'] as String,
    timeRange: map['timeRange'] as String,
    status: map['status'] as String,
    role: map['role'] as String,
    rating: (map['rating'] as num).toDouble(),
    location: map['location'] as String,
    eta: map['eta'] as String,
    imageUrl: map['imageUrl'] as String,
    semanticLabel: map['semanticLabel'] as String,
  );
}


import '../../../core/app_export.dart';

class GreetingHeaderWidget extends StatelessWidget {
  final VoidCallback onNotificationTap;

  const GreetingHeaderWidget({super.key, required this.onNotificationTap});

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Avatar
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppTheme.primaryContainer, width: 2.5),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primary.withAlpha(38),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: ClipOval(
            child: CustomImageWidget(
              imageUrl:
                  'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg',
              width: 48,
              height: 48,
              fit: BoxFit.cover,
              semanticLabel:
                  'Professional headshot of a South Asian woman in uniform with short dark hair, emergency dispatcher',
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Name + subtitle
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${_getGreeting()}, Priya!',
                style: GoogleFonts.manrope(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.textPrimary,
                ),
              ),
              Text(
                'Admin — Bengaluru Control Center',
                style: GoogleFonts.manrope(
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        ),
        // Notification bell
        Stack(
          children: [
            InkWell(
              onTap: onNotificationTap,
              borderRadius: BorderRadius.circular(999),
              splashColor: AppTheme.primaryContainer,
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.surfaceVariantLight,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: 'notifications',
                    color: AppTheme.textPrimary,
                    size: 22,
                  ),
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: AppTheme.sosRed,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 1.5),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}


import '../../../core/app_export.dart';

class HomeMetricsRowWidget extends StatelessWidget {
  const HomeMetricsRowWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final metrics = [
      _Metric('Active Cases', '3', AppTheme.sosRed, 'emergency'),
      _Metric('Units Deployed', '8', AppTheme.primary, 'directions_car'),
      _Metric('Signals Cleared', '12', AppTheme.signalGreen, 'traffic'),
    ];

    return Row(
      children: metrics.asMap().entries.map((entry) {
        final m = entry.value;
        final isLast = entry.key == metrics.length - 1;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: isLast ? 0 : 8),
            child: _MetricCard(metric: m),
          ),
        );
      }).toList(),
    );
  }
}

class _Metric {
  final String label;
  final String value;
  final Color color;
  final String icon;
  _Metric(this.label, this.value, this.color, this.icon);
}

class _MetricCard extends StatelessWidget {
  final _Metric metric;
  const _MetricCard({required this.metric});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: BoxDecoration(
        color: metric.color.withAlpha(20),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: metric.color.withAlpha(51), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomIconWidget(
            iconName: metric.icon,
            color: metric.color,
            size: 20,
          ),
          const SizedBox(height: 8),
          Text(
            metric.value,
            style: GoogleFonts.manrope(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: metric.color,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(height: 2),
          Text(
            metric.label,
            style: GoogleFonts.manrope(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

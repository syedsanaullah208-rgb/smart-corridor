
import '../../../core/app_export.dart';

// Internal model for UnitCardWidget — matches _UnitModel in home_screen.dart
class UnitData {
  final String id;
  final String name;
  final String timeRange;
  final String status;
  final String role;
  final double rating;
  final String location;
  final String eta;
  final String imageUrl;
  final String semanticLabel;

  const UnitData({
    required this.id,
    required this.name,
    required this.timeRange,
    required this.status,
    required this.role,
    required this.rating,
    required this.location,
    required this.eta,
    required this.imageUrl,
    required this.semanticLabel,
  });
}

// Adapter — converts _UnitModel → UnitData for the widget
class UnitCardWidget extends StatefulWidget {
  final dynamic unit;

  const UnitCardWidget({super.key, required this.unit});

  @override
  State<UnitCardWidget> createState() => _UnitCardWidgetState();
}

class _UnitCardWidgetState extends State<UnitCardWidget> {
  bool _isPressed = false;

  StatusType _mapStatus(String s) {
    switch (s) {
      case 'enRoute':
        return StatusType.enRoute;
      case 'standby':
        return StatusType.standby;
      case 'arrived':
        return StatusType.arrived;
      case 'active':
        return StatusType.active;
      case 'critical':
        return StatusType.critical;
      default:
        return StatusType.standby;
    }
  }

  Color _getAccentColor(String status) {
    switch (status) {
      case 'enRoute':
        return AppTheme.secondary;
      case 'arrived':
        return AppTheme.primary;
      case 'active':
        return AppTheme.signalGreen;
      case 'critical':
        return AppTheme.sosRed;
      default:
        return AppTheme.warning;
    }
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.unit;
    final accentColor = _getAccentColor(u.status as String);

    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: () {},
      child: AnimatedScale(
        scale: _isPressed ? 0.98 : 1.0,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOutCubic,
        child: Container(
          decoration: BoxDecoration(
            color: AppTheme.surfaceLight,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(18),
                blurRadius: 12,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Green left accent strip — anatomy locked
                  Container(width: 5, color: accentColor),
                  const SizedBox(width: 14),
                  // Avatar
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    child: Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: accentColor.withAlpha(77),
                          width: 2,
                        ),
                      ),
                      child: ClipOval(
                        child: CustomImageWidget(
                          imageUrl: u.imageUrl as String,
                          width: 52,
                          height: 52,
                          fit: BoxFit.cover,
                          semanticLabel: u.semanticLabel as String,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Content column — anatomy locked
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Name + status badge
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  u.name as String,
                                  style: GoogleFonts.manrope(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.textPrimary,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const SizedBox(width: 6),
                              StatusBadgeWidget(
                                status: _mapStatus(u.status as String),
                                compact: true,
                              ),
                            ],
                          ),
                          const SizedBox(height: 5),
                          // Time range with clock icon
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'timer',
                                color: AppTheme.textMuted,
                                size: 12,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                u.timeRange as String,
                                style: GoogleFonts.manrope(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400,
                                  color: AppTheme.textMuted,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          // Location
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'location_on',
                                color: AppTheme.textMuted,
                                size: 12,
                              ),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  u.location as String,
                                  style: GoogleFonts.manrope(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w400,
                                    color: AppTheme.textMuted,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          // Rating + role row
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'star',
                                color: const Color(0xFFEAB308),
                                size: 13,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                (u.rating as double).toStringAsFixed(1),
                                style: GoogleFonts.manrope(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.textPrimary,
                                ),
                              ),
                              const SizedBox(width: 8),
                              CustomIconWidget(
                                iconName: 'person',
                                color: AppTheme.textMuted,
                                size: 12,
                              ),
                              const SizedBox(width: 3),
                              Expanded(
                                child: Text(
                                  u.role as String,
                                  style: GoogleFonts.manrope(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w400,
                                    color: AppTheme.textMuted,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Chevron — anatomy locked
                  Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: Center(
                      child: Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceVariantLight,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: CustomIconWidget(
                            iconName: 'chevron_right',
                            color: AppTheme.textSecondary,
                            size: 16,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


import '../../core/app_export.dart';
import './widgets/incident_alert_list_widget.dart';
import './widgets/police_map_section_widget.dart';
import './widgets/police_metrics_widget.dart';
import './widgets/signal_override_grid_widget.dart';

class PoliceControlPanelScreen extends StatefulWidget {
  const PoliceControlPanelScreen({super.key});

  @override
  State<PoliceControlPanelScreen> createState() =>
      _PoliceControlPanelScreenState();
}

class _PoliceControlPanelScreenState extends State<PoliceControlPanelScreen>
    with SingleTickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production — police panel state
  int _navIndex = 0;
  bool _broadcastActive = false;
  late AnimationController _fabPulse;
  late Animation<double> _fabScale;

  @override
  void initState() {
    super.initState();
    _fabPulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _fabScale = Tween<double>(
      begin: 1.0,
      end: 1.08,
    ).animate(CurvedAnimation(parent: _fabPulse, curve: Curves.easeInOutSine));
  }

  @override
  void dispose() {
    _fabPulse.dispose();
    super.dispose();
  }

  void _toggleBroadcast() {
    setState(() => _broadcastActive = !_broadcastActive);
    if (_broadcastActive) {
      _fabPulse.repeat(reverse: true);
    } else {
      _fabPulse.stop();
      _fabPulse.reset();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: _buildAppBar(context),
      body: SafeArea(
        top: false,
        child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
      ),
      floatingActionButton: _buildVoiceAlertFab(),
      bottomNavigationBar: isTablet
          ? null
          : AppNavigation(
              currentIndex: _navIndex,
              onDestinationSelected: (i) => setState(() => _navIndex = i),
            ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: AppTheme.surfaceLight,
      elevation: 0,
      scrolledUnderElevation: 1,
      surfaceTintColor: AppTheme.primary.withAlpha(13),
      leading: IconButton(
        icon: CustomIconWidget(
          iconName: 'arrow_back',
          color: AppTheme.textPrimary,
          size: 20,
        ),
        onPressed: () => Navigator.of(context).pop(),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Police Control Panel',
            style: GoogleFonts.manrope(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
          Text(
            'Bengaluru Traffic Command',
            style: GoogleFonts.manrope(
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: AppTheme.textMuted,
            ),
          ),
        ],
      ),
      actions: [
        // Signal override master toggle
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: Center(
            child: GestureDetector(
              onTap: () {},
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.signalOverride.withAlpha(26),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: AppTheme.signalOverride.withAlpha(102),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'power',
                      color: AppTheme.signalOverride,
                      size: 14,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      'Override',
                      style: GoogleFonts.manrope(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.signalOverride,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        IconButton(
          icon: CustomIconWidget(
            iconName: 'tune',
            color: AppTheme.textPrimary,
            size: 22,
          ),
          onPressed: () {},
        ),
      ],
    );
  }

  Widget _buildPhoneLayout() {
    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        // Metrics row
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: const PoliceMetricsWidget(),
          ),
        ),
        // Live map section
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: PoliceMapSectionWidget(),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 16)),
        // Signal override grid
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _buildSectionHeader(
              'Signal Override',
              'View All',
              icon: 'traffic',
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 10)),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: const SignalOverrideGridWidget(),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
        // Incident alerts
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _buildSectionHeader(
              'Incident Alerts',
              'View All',
              icon: 'warning',
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 10)),
        const IncidentAlertListWidget(),
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Row(
      children: [
        AppNavigation(
          currentIndex: _navIndex,
          onDestinationSelected: (i) => setState(() => _navIndex = i),
        ),
        // Left: map + metrics
        Expanded(
          flex: 6,
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: const PoliceMetricsWidget(),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: PoliceMapSectionWidget(),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 16)),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _buildSectionHeader(
                    'Signal Override',
                    'View All',
                    icon: 'traffic',
                  ),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 10)),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: const SignalOverrideGridWidget(),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 80)),
            ],
          ),
        ),
        // Right: incident list
        SizedBox(
          width: 340,
          child: Container(
            color: AppTheme.surfaceLight,
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                    child: _buildSectionHeader(
                      'Incident Alerts',
                      'View All',
                      icon: 'warning',
                    ),
                  ),
                ),
                const IncidentAlertListWidget(),
                const SliverToBoxAdapter(child: SizedBox(height: 80)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(
    String title,
    String action, {
    required String icon,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            CustomIconWidget(iconName: icon, color: AppTheme.primary, size: 18),
            const SizedBox(width: 8),
            Text(
              title,
              style: GoogleFonts.manrope(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
            ),
          ],
        ),
        InkWell(
          onTap: () {},
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Row(
              children: [
                Text(
                  action,
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primary,
                  ),
                ),
                const SizedBox(width: 3),
                CustomIconWidget(
                  iconName: 'arrow_forward',
                  color: AppTheme.primary,
                  size: 12,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildVoiceAlertFab() {
    return AnimatedBuilder(
      animation: _fabScale,
      builder: (context, child) {
        return Transform.scale(
          scale: _broadcastActive ? _fabScale.value : 1.0,
          child: child,
        );
      },
      child: FloatingActionButton.extended(
        onPressed: _toggleBroadcast,
        backgroundColor: _broadcastActive ? AppTheme.sosRed : AppTheme.primary,
        icon: CustomIconWidget(
          iconName: _broadcastActive ? 'volume_up' : 'campaign',
          color: Colors.white,
          size: 20,
        ),
        label: Text(
          _broadcastActive ? 'Broadcasting...' : 'Voice Alert',
          style: GoogleFonts.manrope(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        elevation: _broadcastActive ? 8 : 4,
      ),
    );
  }
}

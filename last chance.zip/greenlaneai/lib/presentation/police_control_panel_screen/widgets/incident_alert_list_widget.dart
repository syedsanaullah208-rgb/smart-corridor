
import '../../../core/app_export.dart';

class IncidentAlertListWidget extends StatefulWidget {
  const IncidentAlertListWidget({super.key});

  @override
  State<IncidentAlertListWidget> createState() =>
      _IncidentAlertListWidgetState();
}

class _IncidentAlertListWidgetState extends State<IncidentAlertListWidget>
    with SingleTickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production — incident list state
  late AnimationController _entranceController;
  late List<Animation<Offset>> _slides;
  late List<Animation<double>> _fades;

  final List<Map<String, dynamic>> _incidentMaps = [
    {
      'id': 'INC-2026-0847',
      'type': 'Road Accident',
      'location': 'Outer Ring Road, near Marathahalli',
      'severity': 'critical',
      'assignedUnits': ['AMB-001', 'POL-012'],
      'elapsed': '4 min ago',
      'description': 'Multi-vehicle collision, 3 casualties reported',
      'signalsCleared': 5,
    },
    {
      'id': 'INC-2026-0846',
      'type': 'Medical Emergency',
      'location': 'Indiranagar 12th Main',
      'severity': 'warning',
      'assignedUnits': ['AMB-003'],
      'elapsed': '11 min ago',
      'description': 'Cardiac arrest, patient conscious',
      'signalsCleared': 2,
    },
    {
      'id': 'INC-2026-0845',
      'type': 'Traffic Obstruction',
      'location': 'Silk Board Junction, southbound',
      'severity': 'warning',
      'assignedUnits': ['POL-007'],
      'elapsed': '18 min ago',
      'description': 'Overturned vehicle blocking 2 lanes',
      'signalsCleared': 0,
    },
    {
      'id': 'INC-2026-0844',
      'type': 'Fire Emergency',
      'location': 'Koramangala 4th Block',
      'severity': 'critical',
      'assignedUnits': ['AMB-009', 'POL-007'],
      'elapsed': '27 min ago',
      'description': 'Commercial building fire, evacuation in progress',
      'signalsCleared': 3,
    },
    {
      'id': 'INC-2026-0843',
      'type': 'Road Accident',
      'location': 'MG Road flyover, eastbound',
      'severity': 'active',
      'assignedUnits': ['AMB-001'],
      'elapsed': '43 min ago',
      'description': 'Minor collision, no casualties, tow requested',
      'signalsCleared': 1,
    },
  ];

  late List<_IncidentModel> _incidents;

  @override
  void initState() {
    super.initState();
    _incidents = _incidentMaps.map(_IncidentModel.fromMap).toList();

    _entranceController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 400 + _incidents.length * 70),
    );

    _slides = List.generate(_incidents.length, (i) {
      final start = (i * 0.14).clamp(0.0, 0.65);
      final end = (start + 0.38).clamp(0.0, 1.0);
      return Tween<Offset>(
        begin: const Offset(0.05, 0),
        end: Offset.zero,
      ).animate(
        CurvedAnimation(
          parent: _entranceController,
          curve: Interval(start, end, curve: Curves.easeOutCubic),
        ),
      );
    });

    _fades = List.generate(_incidents.length, (i) {
      final start = (i * 0.14).clamp(0.0, 0.65);
      final end = (start + 0.32).clamp(0.0, 1.0);
      return Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: _entranceController,
          curve: Interval(start, end, curve: Curves.easeOut),
        ),
      );
    });

    WidgetsBinding.instance.addPostFrameCallback(
      (_) => _entranceController.forward(),
    );
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate((context, index) {
        return AnimatedBuilder(
          animation: _entranceController,
          builder: (context, child) {
            return SlideTransition(
              position: _slides[index],
              child: FadeTransition(opacity: _fades[index], child: child),
            );
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
            child: _IncidentCard(
              incident: _incidents[index],
              onAssign: () {},
              onView: () {},
            ),
          ),
        );
      }, childCount: _incidents.length),
    );
  }
}

class _IncidentCard extends StatelessWidget {
  final _IncidentModel incident;
  final VoidCallback onAssign;
  final VoidCallback onView;

  const _IncidentCard({
    required this.incident,
    required this.onAssign,
    required this.onView,
  });

  Color _severityColor(String s) {
    switch (s) {
      case 'critical':
        return AppTheme.sosRed;
      case 'warning':
        return AppTheme.warning;
      case 'active':
        return AppTheme.primary;
      default:
        return AppTheme.textMuted;
    }
  }

  StatusType _severityStatus(String s) {
    switch (s) {
      case 'critical':
        return StatusType.critical;
      case 'warning':
        return StatusType.warning;
      case 'active':
        return StatusType.active;
      default:
        return StatusType.resolved;
    }
  }

  IconData _typeIcon(String type) {
    switch (type) {
      case 'Road Accident':
        return Icons.car_crash_rounded;
      case 'Medical Emergency':
        return Icons.local_hospital_rounded;
      case 'Traffic Obstruction':
        return Icons.traffic_rounded;
      case 'Fire Emergency':
        return Icons.local_fire_department_rounded;
      default:
        return Icons.warning_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _severityColor(incident.severity);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withAlpha(64), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(15),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Left accent strip
              Container(width: 5, color: color),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Top row: type icon + title + status + time
                      Row(
                        children: [
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: color.withAlpha(26),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Icon(
                                _typeIcon(incident.type),
                                color: color,
                                size: 18,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  incident.type,
                                  style: GoogleFonts.manrope(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.textPrimary,
                                  ),
                                ),
                                Text(
                                  incident.id,
                                  style: GoogleFonts.manrope(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w500,
                                    color: AppTheme.textMuted,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              StatusBadgeWidget(
                                status: _severityStatus(incident.severity),
                                compact: true,
                              ),
                              const SizedBox(height: 3),
                              Text(
                                incident.elapsed,
                                style: GoogleFonts.manrope(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w400,
                                  color: AppTheme.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      // Location
                      Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'location_on',
                            color: AppTheme.textMuted,
                            size: 12,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              incident.location,
                              style: GoogleFonts.manrope(
                                fontSize: 11,
                                fontWeight: FontWeight.w400,
                                color: AppTheme.textSecondary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      // Description
                      Text(
                        incident.description,
                        style: GoogleFonts.manrope(
                          fontSize: 11,
                          fontWeight: FontWeight.w400,
                          color: AppTheme.textMuted,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 10),
                      // Units + actions row
                      Row(
                        children: [
                          // Assigned units
                          Expanded(
                            child: Wrap(
                              spacing: 5,
                              children: incident.assignedUnits.map((u) {
                                return Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 3,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppTheme.primary.withAlpha(20),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                      color: AppTheme.primary.withAlpha(51),
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    u,
                                    style: GoogleFonts.manrope(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.primary,
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // View button
                          GestureDetector(
                            onTap: onView,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.primary,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                'View',
                                style: GoogleFonts.manrope(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      // Signals cleared chip
                      if (incident.signalsCleared > 0) ...[
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'traffic',
                              color: AppTheme.signalGreen,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${incident.signalsCleared} signals cleared on corridor',
                              style: GoogleFonts.manrope(
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                color: AppTheme.signalGreen,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _IncidentModel {
  final String id;
  final String type;
  final String location;
  final String severity;
  final List<String> assignedUnits;
  final String elapsed;
  final String description;
  final int signalsCleared;

  _IncidentModel({
    required this.id,
    required this.type,
    required this.location,
    required this.severity,
    required this.assignedUnits,
    required this.elapsed,
    required this.description,
    required this.signalsCleared,
  });

  factory _IncidentModel.fromMap(Map<String, dynamic> map) => _IncidentModel(
    id: map['id'] as String,
    type: map['type'] as String,
    location: map['location'] as String,
    severity: map['severity'] as String,
    assignedUnits: List<String>.from(map['assignedUnits'] as List),
    elapsed: map['elapsed'] as String,
    description: map['description'] as String,
    signalsCleared: map['signalsCleared'] as int,
  );
}

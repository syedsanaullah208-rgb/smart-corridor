import 'package:flutter/foundation.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../core/app_export.dart';

class PoliceMapSectionWidget extends StatefulWidget {
  const PoliceMapSectionWidget({super.key});

  @override
  State<PoliceMapSectionWidget> createState() => _PoliceMapSectionWidgetState();
}

class _PoliceMapSectionWidgetState extends State<PoliceMapSectionWidget> {
  // TODO: Replace with Riverpod/Bloc for production — map state
  GoogleMapController? _mapController;
  bool _showHeatmap = true;
  bool _showCorridors = true;

  static const _bengaluruCenter = LatLng(12.9716, 77.5946);

  final Set<Marker> _markers = {
    Marker(
      markerId: const MarkerId('amb_001'),
      position: const LatLng(12.9752, 77.6094),
      infoWindow: const InfoWindow(
        title: 'AMB-001 — En Route',
        snippet: 'MG Road → Victoria Hospital · ETA 4 min',
      ),
    ),
    Marker(
      markerId: const MarkerId('amb_009'),
      position: const LatLng(12.9341, 77.6269),
      infoWindow: const InfoWindow(
        title: 'AMB-009 — Arrived',
        snippet: 'Manipal Hospital',
      ),
    ),
    Marker(
      markerId: const MarkerId('pol_007'),
      position: const LatLng(12.9181, 77.6237),
      infoWindow: const InfoWindow(
        title: 'POL-007 — Traffic Control',
        snippet: 'Silk Board Junction',
      ),
    ),
    Marker(
      markerId: const MarkerId('incident_1'),
      position: const LatLng(12.9784, 77.6408),
      infoWindow: const InfoWindow(
        title: 'INCIDENT — Critical',
        snippet: 'Outer Ring Road · Accident reported',
      ),
    ),
  };

  final Set<Polyline> _corridorPolylines = {
    Polyline(
      polylineId: const PolylineId('corridor_1'),
      points: const [
        LatLng(12.9752, 77.6094),
        LatLng(12.9700, 77.6000),
        LatLng(12.9650, 77.5950),
        LatLng(12.9600, 77.5900),
      ],
      color: Color(0xFF16A34A),
      width: 5,
      patterns: [],
    ),
  };

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Map header row
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Live Traffic Map',
              style: GoogleFonts.manrope(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
            ),
            Row(
              children: [
                _MapToggleChip(
                  label: 'Heatmap',
                  active: _showHeatmap,
                  onTap: () => setState(() => _showHeatmap = !_showHeatmap),
                ),
                const SizedBox(width: 6),
                _MapToggleChip(
                  label: 'Corridors',
                  active: _showCorridors,
                  onTap: () => setState(() => _showCorridors = !_showCorridors),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 10),
        // Map container
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Container(
            height: isTablet ? 320 : 220,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(26),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: kIsWeb ? _buildWebMapFallback() : _buildGoogleMap(),
          ),
        ),
        const SizedBox(height: 10),
        // Map legend
        _buildMapLegend(),
      ],
    );
  }

  Widget _buildGoogleMap() {
    return GoogleMap(
      initialCameraPosition: const CameraPosition(
        target: _bengaluruCenter,
        zoom: 12.5,
      ),
      markers: _markers,
      polylines: _corridorPolylines,
      onMapCreated: (controller) => _mapController = controller,
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false,
      mapToolbarEnabled: false,
      compassEnabled: true,
      trafficEnabled: true,
    );
  }

  Widget _buildWebMapFallback() {
    return Container(
      color: const Color(0xFFE8F2EC),
      child: Stack(
        children: [
          // Simulated map background
          Positioned.fill(
            child: CustomImageWidget(
              imageUrl:
                  'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg',
              fit: BoxFit.cover,
              semanticLabel:
                  'Aerial satellite view of Bengaluru city road network showing major intersections',
            ),
          ),
          // Overlay
          Positioned.fill(
            child: Container(color: AppTheme.primary.withAlpha(38)),
          ),
          // Center label
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(235),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(color: Colors.black.withAlpha(26), blurRadius: 8),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: 'my_location',
                    color: AppTheme.primary,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Bengaluru Live Map — Add API Key to activate',
                    style: GoogleFonts.manrope(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Simulated unit pins
          ..._buildSimulatedPins(),
        ],
      ),
    );
  }

  List<Widget> _buildSimulatedPins() {
    final pins = [
      _SimPin(0.45, 0.35, AppTheme.secondary, 'AMB'),
      _SimPin(0.68, 0.62, AppTheme.primary, 'AMB'),
      _SimPin(0.30, 0.70, AppTheme.primary, 'POL'),
      _SimPin(0.55, 0.22, AppTheme.sosRed, '!'),
    ];
    return pins.map((p) {
      return Positioned(
        left: null,
        top: null,
        child: Align(
          alignment: Alignment(p.left * 2 - 1, p.top * 2 - 1),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: p.color,
              borderRadius: BorderRadius.circular(999),
              boxShadow: [
                BoxShadow(
                  color: p.color.withAlpha(102),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Text(
              p.label,
              style: GoogleFonts.manrope(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ),
        ),
      );
    }).toList();
  }

  Widget _buildMapLegend() {
    final items = [
      _LegendItem(AppTheme.secondary, 'Ambulance'),
      _LegendItem(AppTheme.primary, 'Police'),
      _LegendItem(AppTheme.signalGreen, 'Corridor'),
      _LegendItem(AppTheme.sosRed, 'Incident'),
    ];
    return Row(
      children: items.map((item) {
        return Padding(
          padding: const EdgeInsets.only(right: 14),
          child: Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: item.color,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 5),
              Text(
                item.label,
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  fontWeight: FontWeight.w400,
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _MapToggleChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _MapToggleChip({
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: active ? AppTheme.primary : AppTheme.surfaceVariantLight,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: active ? AppTheme.primary : AppTheme.primary.withAlpha(51),
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: GoogleFonts.manrope(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: active ? Colors.white : AppTheme.primary,
          ),
        ),
      ),
    );
  }
}

class _SimPin {
  final double left;
  final double top;
  final Color color;
  final String label;
  _SimPin(this.left, this.top, this.color, this.label);
}

class _LegendItem {
  final Color color;
  final String label;
  _LegendItem(this.color, this.label);
}
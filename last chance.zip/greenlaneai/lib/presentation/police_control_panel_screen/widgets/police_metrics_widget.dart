
import '../../../core/app_export.dart';

class PoliceMetricsWidget extends StatelessWidget {
  const PoliceMetricsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final metrics = [
      _PMetric('Active Signals', '24', AppTheme.signalGreen, 'traffic', '+2'),
      _PMetric('Incidents Today', '7', AppTheme.sosRed, 'warning', '+1'),
      _PMetric('Units Deployed', '11', AppTheme.primary, 'directions_car', ''),
      _PMetric('Overrides', '3', AppTheme.signalOverride, 'power', 'LIVE'),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 2.2,
      ),
      itemCount: metrics.length,
      itemBuilder: (context, i) => _MetricTile(metric: metrics[i]),
    );
  }
}

class _PMetric {
  final String label;
  final String value;
  final Color color;
  final String icon;
  final String tag;
  _PMetric(this.label, this.value, this.color, this.icon, this.tag);
}

class _MetricTile extends StatelessWidget {
  final _PMetric metric;
  const _MetricTile({required this.metric});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: metric.color.withAlpha(20),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: metric.color.withAlpha(51), width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: metric.color.withAlpha(38),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: metric.icon,
                color: metric.color,
                size: 18,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Text(
                      metric.value,
                      style: GoogleFonts.manrope(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: metric.color,
                        fontFeatures: const [FontFeature.tabularFigures()],
                      ),
                    ),
                    if (metric.tag.isNotEmpty) ...[
                      const SizedBox(width: 5),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: metric.color.withAlpha(38),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          metric.tag,
                          style: GoogleFonts.manrope(
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: metric.color,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                Text(
                  metric.label,
                  style: GoogleFonts.manrope(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

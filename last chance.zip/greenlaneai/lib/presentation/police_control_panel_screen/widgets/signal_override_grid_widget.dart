
import '../../../core/app_export.dart';

class SignalOverrideGridWidget extends StatefulWidget {
  const SignalOverrideGridWidget({super.key});

  @override
  State<SignalOverrideGridWidget> createState() =>
      _SignalOverrideGridWidgetState();
}

class _SignalOverrideGridWidgetState extends State<SignalOverrideGridWidget> {
  // TODO: Replace with Riverpod/Bloc for production — signal override state

  final List<Map<String, dynamic>> _signalMaps = [
    {
      'id': 'SIG-MG-01',
      'intersection': 'MG Road & Brigade Rd',
      'state': 'override',
      'duration': '3:42',
      'units': 2,
    },
    {
      'id': 'SIG-SB-07',
      'intersection': 'Silk Board Junction',
      'state': 'green',
      'duration': '1:20',
      'units': 1,
    },
    {
      'id': 'SIG-ORR-12',
      'intersection': 'Outer Ring Rd & Sarjapur',
      'state': 'red',
      'duration': '0:55',
      'units': 0,
    },
    {
      'id': 'SIG-IND-04',
      'intersection': 'Indiranagar 100ft Rd',
      'state': 'amber',
      'duration': '2:05',
      'units': 1,
    },
    {
      'id': 'SIG-KOR-09',
      'intersection': 'Koramangala 5th Block',
      'state': 'green',
      'duration': '0:30',
      'units': 0,
    },
    {
      'id': 'SIG-MAR-03',
      'intersection': 'Marathahalli Bridge',
      'state': 'override',
      'duration': '5:10',
      'units': 3,
    },
  ];

  late List<_SignalModel> _signals;

  @override
  void initState() {
    super.initState();
    _signals = _signalMaps.map(_SignalModel.fromMap).toList();
  }

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.45,
      ),
      itemCount: _signals.length,
      itemBuilder: (context, index) {
        return _SignalCard(
          signal: _signals[index],
          onToggle: () => _toggleSignal(index),
        );
      },
    );
  }

  void _toggleSignal(int index) {
    setState(() {
      final current = _signals[index].state;
      final next = current == 'override' ? 'green' : 'override';
      _signals[index] = _SignalModel(
        id: _signals[index].id,
        intersection: _signals[index].intersection,
        state: next,
        duration: _signals[index].duration,
        units: _signals[index].units,
      );
    });
  }
}

class _SignalCard extends StatelessWidget {
  final _SignalModel signal;
  final VoidCallback onToggle;

  const _SignalCard({required this.signal, required this.onToggle});

  Color _stateColor(String state) {
    switch (state) {
      case 'green':
        return AppTheme.signalGreen;
      case 'red':
        return AppTheme.signalRed;
      case 'amber':
        return AppTheme.signalAmber;
      case 'override':
        return AppTheme.signalOverride;
      default:
        return AppTheme.textMuted;
    }
  }

  StatusType _stateToStatus(String state) {
    switch (state) {
      case 'green':
        return StatusType.greenSignal;
      case 'red':
        return StatusType.redSignal;
      case 'amber':
        return StatusType.amberSignal;
      case 'override':
        return StatusType.overrideSignal;
      default:
        return StatusType.offline;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _stateColor(signal.state);
    final isOverride = signal.state == 'override';

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isOverride
              ? AppTheme.signalOverride.withAlpha(102)
              : const Color(0xFFE8F2EC),
          width: isOverride ? 1.5 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // ID + status
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                signal.id,
                style: GoogleFonts.manrope(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textMuted,
                  letterSpacing: 0.3,
                ),
              ),
              StatusBadgeWidget(
                status: _stateToStatus(signal.state),
                compact: true,
              ),
            ],
          ),
          // Intersection name
          Text(
            signal.intersection,
            style: GoogleFonts.manrope(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimary,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          // Duration + units row
          Row(
            children: [
              CustomIconWidget(
                iconName: 'timer',
                color: AppTheme.textMuted,
                size: 11,
              ),
              const SizedBox(width: 3),
              Text(
                signal.duration,
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.textMuted,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
              const Spacer(),
              // Toggle button
              GestureDetector(
                onTap: onToggle,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: isOverride
                        ? AppTheme.signalOverride
                        : AppTheme.surfaceVariantLight,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    isOverride ? 'Release' : 'Override',
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: isOverride
                          ? Colors.white
                          : AppTheme.signalOverride,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SignalModel {
  final String id;
  final String intersection;
  final String state;
  final String duration;
  final int units;

  _SignalModel({
    required this.id,
    required this.intersection,
    required this.state,
    required this.duration,
    required this.units,
  });

  factory _SignalModel.fromMap(Map<String, dynamic> map) => _SignalModel(
    id: map['id'] as String,
    intersection: map['intersection'] as String,
    state: map['state'] as String,
    duration: map['duration'] as String,
    units: map['units'] as int,
  );
}

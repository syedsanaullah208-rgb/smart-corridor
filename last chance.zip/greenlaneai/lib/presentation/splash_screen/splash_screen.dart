
import '../../core/app_export.dart';
import './widgets/splash_cta_section_widget.dart';
import './widgets/splash_hero_widget.dart';
import './widgets/splash_progress_pills_widget.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production — splash animation state
  late AnimationController _bgController;
  late AnimationController _logoController;
  late AnimationController _contentController;

  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _contentSlide;
  late Animation<double> _contentOpacity;
  late Animation<Color?> _bgColorTop;
  late Animation<Color?> _bgColorBottom;

  final int _currentStep = 0;

  @override
  void initState() {
    super.initState();

    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _contentController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );

    _bgColorTop =
        ColorTween(
          begin: const Color(0xFF0D4A22),
          end: const Color(0xFF1B7A3E),
        ).animate(
          CurvedAnimation(parent: _bgController, curve: Curves.easeOutCubic),
        );

    _bgColorBottom =
        ColorTween(
          begin: const Color(0xFF1B7A3E),
          end: const Color(0xFFB8EAC8),
        ).animate(
          CurvedAnimation(parent: _bgController, curve: Curves.easeOutCubic),
        );

    _logoScale = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.easeOutBack),
    );

    _logoOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
      ),
    );

    _contentSlide = Tween<double>(begin: 40.0, end: 0.0).animate(
      CurvedAnimation(parent: _contentController, curve: Curves.easeOutCubic),
    );

    _contentOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _contentController, curve: Curves.easeOut),
    );

    _startAnimationSequence();
  }

  Future<void> _startAnimationSequence() async {
    await Future.delayed(const Duration(milliseconds: 200));
    _bgController.forward();
    await Future.delayed(const Duration(milliseconds: 300));
    _logoController.forward();
    await Future.delayed(const Duration(milliseconds: 700));
    _contentController.forward();
    await Future.delayed(const Duration(milliseconds: 3200));
    if (mounted) {
      _navigateToHome();
    }
  }

  void _navigateToHome() {
    Navigator.pushNamedAndRemoveUntil(
      context,
      AppRoutes.homeScreen,
      (route) => false,
    );
  }

  @override
  void dispose() {
    _bgController.dispose();
    _logoController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width >= 600;

    return Scaffold(
      body: AnimatedBuilder(
        animation: _bgController,
        builder: (context, child) {
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  _bgColorTop.value ?? AppTheme.primaryDark,
                  _bgColorBottom.value ?? AppTheme.primaryContainer,
                ],
              ),
            ),
            child: child,
          );
        },
        child: SafeArea(
          child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(size),
        ),
      ),
    );
  }

  Widget _buildPhoneLayout(Size size) {
    return Column(
      children: [
        const SizedBox(height: 20),
        SplashProgressPillsWidget(currentStep: _currentStep),
        const SizedBox(height: 16),
        Expanded(
          child: SplashHeroWidget(
            logoScale: _logoScale,
            logoOpacity: _logoOpacity,
          ),
        ),
        AnimatedBuilder(
          animation: _contentController,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, _contentSlide.value),
              child: Opacity(opacity: _contentOpacity.value, child: child),
            );
          },
          child: SplashCtaSectionWidget(onGetStarted: _navigateToHome),
        ),
        const SizedBox(height: 32),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Center(
      child: SizedBox(
        width: 480,
        child: Column(
          children: [
            const SizedBox(height: 24),
            SplashProgressPillsWidget(currentStep: _currentStep),
            const SizedBox(height: 16),
            Expanded(
              child: SplashHeroWidget(
                logoScale: _logoScale,
                logoOpacity: _logoOpacity,
              ),
            ),
            AnimatedBuilder(
              animation: _contentController,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _contentSlide.value),
                  child: Opacity(opacity: _contentOpacity.value, child: child),
                );
              },
              child: SplashCtaSectionWidget(onGetStarted: _navigateToHome),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

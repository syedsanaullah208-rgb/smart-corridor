
import '../../../core/app_export.dart';

class SplashHeroWidget extends StatelessWidget {
  final Animation<double> logoScale;
  final Animation<double> logoOpacity;

  const SplashHeroWidget({
    super.key,
    required this.logoScale,
    required this.logoOpacity,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Hero image — smart city aerial view
        Positioned.fill(
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(32),
              bottomRight: Radius.circular(32),
            ),
            child: CustomImageWidget(
              imageUrl:
                  'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg',
              fit: BoxFit.cover,
              semanticLabel:
                  'Aerial view of a modern smart city at night with illuminated roads and traffic patterns',
            ),
          ),
        ),
        // Dark overlay gradient
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(32),
                bottomRight: Radius.circular(32),
              ),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withAlpha(64),
                  Colors.black.withAlpha(140),
                ],
              ),
            ),
          ),
        ),
        // Centered logo + app name
        Center(
          child: AnimatedBuilder(
            animation: logoScale,
            builder: (context, child) {
              return Transform.scale(
                scale: logoScale.value,
                child: Opacity(opacity: logoOpacity.value, child: child),
              );
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primary.withAlpha(102),
                        blurRadius: 32,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: 'emergency',
                      color: AppTheme.primary,
                      size: 52,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'GreenLane AI',
                  style: GoogleFonts.manrope(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Smart Emergency Coordination',
                  style: GoogleFonts.manrope(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Colors.white.withAlpha(217),
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ),
        // Floating info card at bottom of hero
        Positioned(
          bottom: 20,
          left: 20,
          right: 20,
          child: _buildFloatingInfoCard(),
        ),
      ],
    );
  }

  Widget _buildFloatingInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(242),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(31),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: 'local_police',
                color: AppTheme.primary,
                size: 24,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AI-Powered Emergency Coordination',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  'Reduce response times with intelligent green corridors and real-time dispatch.',
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    fontWeight: FontWeight.w400,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

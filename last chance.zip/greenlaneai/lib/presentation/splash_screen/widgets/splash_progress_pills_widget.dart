import 'package:flutter/material.dart';
import '../../../core/app_export.dart';

class SplashProgressPillsWidget extends StatelessWidget {
  final int currentStep;

  const SplashProgressPillsWidget({super.key, required this.currentStep});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (index) {
        final isActive = index == currentStep;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: isActive ? 32 : 10,
          height: 6,
          decoration: BoxDecoration(
            color: isActive ? Colors.white : Colors.white.withAlpha(89),
            borderRadius: BorderRadius.circular(999),
          ),
        );
      }),
    );
  }
}

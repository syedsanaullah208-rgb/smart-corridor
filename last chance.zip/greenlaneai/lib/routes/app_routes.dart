import 'package:flutter/material.dart';

import '../presentation/home_screen/home_screen.dart';
import '../presentation/police_control_panel_screen/police_control_panel_screen.dart';
import '../presentation/splash_screen/splash_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String splashScreen = '/splash-screen';
  static const String homeScreen = '/home-screen';
  static const String policeControlPanelScreen = '/police-control-panel-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    splashScreen: (context) => const SplashScreen(),
    homeScreen: (context) => const HomeScreen(),
    policeControlPanelScreen: (context) => const PoliceControlPanelScreen(),
  };
}

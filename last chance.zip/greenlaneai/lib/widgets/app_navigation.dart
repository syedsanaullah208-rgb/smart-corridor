
import '../core/app_export.dart';

// TODO: Replace with Riverpod/Bloc for production — navigation index state
class AppNavigation extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onDestinationSelected;

  const AppNavigation({
    super.key,
    required this.currentIndex,
    required this.onDestinationSelected,
  });

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;
    if (isTablet) {
      return _buildNavigationRail(context);
    }
    return _buildNavigationBar(context);
  }

  Widget _buildNavigationBar(BuildContext context) {
    return NavigationBar(
      selectedIndex: currentIndex,
      onDestinationSelected: onDestinationSelected,
      height: 68,
      elevation: 8,
      backgroundColor: AppTheme.surfaceLight,
      indicatorColor: AppTheme.primaryContainer,
      destinations: const [
        NavigationDestination(
          icon: CustomIconWidget(
            iconName: 'home_outlined',
            color: AppTheme.textMuted,
            size: 22,
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'home',
            color: AppTheme.primary,
            size: 22,
          ),
          label: 'Home',
        ),
        NavigationDestination(
          icon: CustomIconWidget(
            iconName: 'map_outlined',
            color: AppTheme.textMuted,
            size: 22,
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'map',
            color: AppTheme.primary,
            size: 22,
          ),
          label: 'Live Map',
        ),
        NavigationDestination(
          icon: Badge(
            label: Text('3'),
            child: CustomIconWidget(
              iconName: 'notifications_outlined',
              color: AppTheme.textMuted,
              size: 22,
            ),
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'notifications',
            color: AppTheme.primary,
            size: 22,
          ),
          label: 'Alerts',
        ),
        NavigationDestination(
          icon: CustomIconWidget(
            iconName: 'person_outlined',
            color: AppTheme.textMuted,
            size: 22,
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'person',
            color: AppTheme.primary,
            size: 22,
          ),
          label: 'Profile',
        ),
      ],
    );
  }

  Widget _buildNavigationRail(BuildContext context) {
    return NavigationRail(
      selectedIndex: currentIndex,
      onDestinationSelected: onDestinationSelected,
      extended: MediaQuery.of(context).size.width >= 840,
      backgroundColor: AppTheme.surfaceLight,
      indicatorColor: AppTheme.primaryContainer,
      selectedIconTheme: const IconThemeData(color: AppTheme.primary, size: 22),
      unselectedIconTheme: const IconThemeData(
        color: AppTheme.textMuted,
        size: 22,
      ),
      selectedLabelTextStyle: GoogleFonts.manrope(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: AppTheme.primary,
      ),
      unselectedLabelTextStyle: GoogleFonts.manrope(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: AppTheme.textMuted,
      ),
      destinations: const [
        NavigationRailDestination(
          icon: CustomIconWidget(
            iconName: 'home_outlined',
            color: AppTheme.textMuted,
            size: 22,
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'home',
            color: AppTheme.primary,
            size: 22,
          ),
          label: Text('Home'),
        ),
        NavigationRailDestination(
          icon: CustomIconWidget(
            iconName: 'map_outlined',
            color: AppTheme.textMuted,
            size: 22,
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'map',
            color: AppTheme.primary,
            size: 22,
          ),
          label: Text('Live Map'),
        ),
        NavigationRailDestination(
          icon: CustomIconWidget(
            iconName: 'notifications_outlined',
            color: AppTheme.textMuted,
            size: 22,
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'notifications',
            color: AppTheme.primary,
            size: 22,
          ),
          label: Text('Alerts'),
        ),
        NavigationRailDestination(
          icon: CustomIconWidget(
            iconName: 'person_outlined',
            color: AppTheme.textMuted,
            size: 22,
          ),
          selectedIcon: CustomIconWidget(
            iconName: 'person',
            color: AppTheme.primary,
            size: 22,
          ),
          label: Text('Profile'),
        ),
      ],
    );
  }
}

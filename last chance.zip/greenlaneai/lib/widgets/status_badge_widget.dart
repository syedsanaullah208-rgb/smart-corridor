
import '../core/app_export.dart';

enum StatusType {
  active,
  enRoute,
  standby,
  arrived,
  resolved,
  critical,
  warning,
  greenSignal,
  redSignal,
  overrideSignal,
  amberSignal,
  offline,
}

class StatusBadgeWidget extends StatelessWidget {
  final StatusType status;
  final String? customLabel;
  final bool compact;

  const StatusBadgeWidget({
    super.key,
    required this.status,
    this.customLabel,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final config = _getConfig(status);
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 8 : 10,
        vertical: compact ? 3 : 5,
      ),
      decoration: BoxDecoration(
        color: config.background,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: config.border, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: config.dotColor,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 5),
          Text(
            customLabel ?? config.label,
            style: GoogleFonts.manrope(
              fontSize: compact ? 10 : 11,
              fontWeight: FontWeight.w600,
              color: config.textColor,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  _StatusConfig _getConfig(StatusType type) {
    switch (type) {
      case StatusType.active:
        return _StatusConfig(
          label: 'Active',
          background: const Color(0xFFE8F5EE),
          border: const Color(0xFF4CAF72),
          dotColor: AppTheme.primary,
          textColor: AppTheme.primary,
        );
      case StatusType.enRoute:
        return _StatusConfig(
          label: 'En Route',
          background: const Color(0xFFE3F2FD),
          border: const Color(0xFF90CAF9),
          dotColor: AppTheme.secondary,
          textColor: AppTheme.info,
        );
      case StatusType.standby:
        return _StatusConfig(
          label: 'Standby',
          background: const Color(0xFFFFF8E1),
          border: const Color(0xFFFFCC02),
          dotColor: AppTheme.warning,
          textColor: AppTheme.warning,
        );
      case StatusType.arrived:
        return _StatusConfig(
          label: 'Arrived',
          background: AppTheme.primaryContainer,
          border: AppTheme.primary,
          dotColor: AppTheme.primaryDark,
          textColor: AppTheme.primaryDark,
        );
      case StatusType.resolved:
        return _StatusConfig(
          label: 'Resolved',
          background: const Color(0xFFF3F4F6),
          border: const Color(0xFFD1D5DB),
          dotColor: AppTheme.textMuted,
          textColor: AppTheme.textMuted,
        );
      case StatusType.critical:
        return _StatusConfig(
          label: 'Critical',
          background: AppTheme.sosRedLight,
          border: const Color(0xFFF87171),
          dotColor: AppTheme.sosRed,
          textColor: AppTheme.sosRed,
        );
      case StatusType.warning:
        return _StatusConfig(
          label: 'Warning',
          background: AppTheme.warningLight,
          border: const Color(0xFFFCD34D),
          dotColor: AppTheme.warning,
          textColor: AppTheme.warning,
        );
      case StatusType.greenSignal:
        return _StatusConfig(
          label: 'GREEN',
          background: const Color(0xFFDCFCE7),
          border: AppTheme.signalGreen,
          dotColor: AppTheme.signalGreen,
          textColor: AppTheme.signalGreen,
        );
      case StatusType.redSignal:
        return _StatusConfig(
          label: 'RED',
          background: AppTheme.sosRedLight,
          border: AppTheme.signalRed,
          dotColor: AppTheme.signalRed,
          textColor: AppTheme.signalRed,
        );
      case StatusType.overrideSignal:
        return _StatusConfig(
          label: 'OVERRIDE',
          background: const Color(0xFFF3E8FF),
          border: AppTheme.signalOverride,
          dotColor: AppTheme.signalOverride,
          textColor: AppTheme.signalOverride,
        );
      case StatusType.amberSignal:
        return _StatusConfig(
          label: 'AMBER',
          background: AppTheme.warningLight,
          border: AppTheme.signalAmber,
          dotColor: AppTheme.signalAmber,
          textColor: AppTheme.signalAmber,
        );
      case StatusType.offline:
        return _StatusConfig(
          label: 'Offline',
          background: const Color(0xFFF3F4F6),
          border: const Color(0xFFD1D5DB),
          dotColor: AppTheme.textMuted,
          textColor: AppTheme.textMuted,
        );
    }
  }
}

class _StatusConfig {
  final String label;
  final Color background;
  final Color border;
  final Color dotColor;
  final Color textColor;

  _StatusConfig({
    required this.label,
    required this.background,
    required this.border,
    required this.dotColor,
    required this.textColor,
  });
}

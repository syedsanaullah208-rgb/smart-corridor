'use client';
import React, { useState } from 'react';
import {
  Navigation2,
  AlertTriangle,
  Ambulance,
  Shield,
  CheckCircle,
  Building2,
} from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


// BACKEND INTEGRATION POINT: GET /api/activity-feed?limit=8 (WebSocket for real-time)
const activities = [
  {
    id: 'act-001',
    type: 'corridor',
    icon: Navigation2,
    color: '#4ade80',
    bg: 'rgba(34,197,94,0.1)',
    message: 'Green corridor activated on MG Road → City Hospital',
    time: '12:41',
    ago: 'Just now',
  },
  {
    id: 'act-002',
    type: 'incident',
    icon: AlertTriangle,
    color: '#fca5a5',
    bg: 'rgba(239,68,68,0.1)',
    message: 'New critical incident INC-2851 — multi-vehicle collision, ORR Km 14',
    time: '12:38',
    ago: '3 min ago',
  },
  {
    id: 'act-003',
    type: 'ambulance',
    icon: Ambulance,
    color: '#93c5fd',
    bg: 'rgba(59,130,246,0.1)',
    message: 'AMB-07 dispatched to INC-2851 · ETA 2.8 min',
    time: '12:38',
    ago: '3 min ago',
  },
  {
    id: 'act-004',
    type: 'police',
    icon: Shield,
    color: '#c4b5fd',
    bg: 'rgba(139,92,246,0.1)',
    message: 'Units P-14 and P-22 assigned to INC-2851 corridor duty',
    time: '12:37',
    ago: '4 min ago',
  },
  {
    id: 'act-005',
    type: 'resolved',
    icon: CheckCircle,
    color: '#4ade80',
    bg: 'rgba(34,197,94,0.1)',
    message: 'INC-2845 resolved — JP Nagar minor collision cleared',
    time: '12:34',
    ago: '7 min ago',
  },
  {
    id: 'act-006',
    type: 'hospital',
    icon: Building2,
    color: '#fcd34d',
    bg: 'rgba(245,158,11,0.1)',
    message: 'Apollo Hospital ICU capacity alert — 8% beds remaining',
    time: '12:29',
    ago: '12 min ago',
  },
  {
    id: 'act-007',
    type: 'ambulance',
    icon: Ambulance,
    color: '#93c5fd',
    bg: 'rgba(59,130,246,0.1)',
    message: 'AMB-09 arrived on scene — INC-2846 Koramangala cardiac',
    time: '12:26',
    ago: '15 min ago',
  },
  {
    id: 'act-008',
    type: 'corridor',
    icon: Navigation2,
    color: '#94a3b8',
    bg: 'rgba(100,116,139,0.1)',
    message: 'Corridor deactivated — NH48 Junction, INC-2847 resolved',
    time: '12:21',
    ago: '20 min ago',
  },
];

export default function ActivityFeed() {
  const [expanded, setExpanded] = useState(false);
  const visible = expanded ? activities : activities?.slice(0, 5);

  return (
    <div className="card flex flex-col">
      <div
        className="flex items-center justify-between px-5 py-4 border-b"
        style={{ borderColor: 'var(--border)' }}
      >
        <div>
          <h3 className="text-sm font-semibold text-foreground">Live Activity Feed</h3>
          <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
            Real-time operations log
          </p>
        </div>
        <span
          className="flex items-center gap-1.5 text-xs font-semibold"
          style={{ color: '#4ade80' }}
        >
          <span className="w-1.5 h-1.5 rounded-full pulse-dot" style={{ background: '#4ade80' }} />
          Live
        </span>
      </div>
      <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
        {visible?.map((act) => {
          const Icon = act?.icon;
          return (
            <div
              key={act?.id}
              className="flex items-start gap-3 px-5 py-3 transition-colors hover:bg-white/[0.02]"
            >
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                style={{ background: act?.bg }}
              >
                <Icon size={13} style={{ color: act?.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-foreground leading-relaxed">{act?.message}</p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
                  {act?.ago} · {act?.time}
                </p>
              </div>
            </div>
          );
        })}
      </div>
      <button
        onClick={() => setExpanded((e) => !e)}
        className="px-5 py-3 text-xs font-semibold text-center transition-colors hover:text-foreground border-t"
        style={{ color: 'var(--accent)', borderColor: 'var(--border)' }}
      >
        {expanded ? 'Show less' : `Show ${activities?.length - 5} more events`}
      </button>
    </div>
  );
}
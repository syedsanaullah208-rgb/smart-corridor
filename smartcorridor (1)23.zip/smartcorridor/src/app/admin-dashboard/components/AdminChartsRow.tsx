'use client';

import React from 'react';
import dynamic from 'next/dynamic';

const IncidentVolumeChart = dynamic(() => import('./IncidentVolumeChart'), { ssr: false });
const ZoneResponseChart = dynamic(() => import('./ZoneResponseChart'), { ssr: false });

export default function AdminChartsRow() {
  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      <IncidentVolumeChart />
      <ZoneResponseChart />
    </div>
  );
}
'use client';
import React, { useState, useEffect } from 'react';
import { Bell, Search, RefreshCw, Download } from 'lucide-react';

export default function AdminTopbar() {
  const [timeStr, setTimeStr] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const fmt = () => {
      const now = new Date();
      const h = String(now?.getHours())?.padStart(2, '0');
      const m = String(now?.getMinutes())?.padStart(2, '0');
      const s = String(now?.getSeconds())?.padStart(2, '0');
      const d = now?.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
      setTimeStr(`${d} · ${h}:${m}:${s} IST`);
    };
    fmt();
    const id = setInterval(fmt, 1000);
    return () => clearInterval(id);
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1200);
  };

  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <div className="flex items-center gap-3 mb-1">
          <h1 className="text-2xl font-bold text-foreground">Emergency Operations</h1>
          <span
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
            style={{
              background: 'rgba(34,197,94,0.12)',
              color: '#4ade80',
              border: '1px solid rgba(34,197,94,0.3)',
            }}
          >
            <span className="w-1.5 h-1.5 rounded-full pulse-dot" style={{ background: '#4ade80' }} />
            LIVE
          </span>
        </div>
        <p className="text-sm tabular-nums" style={{ color: 'var(--muted-foreground)' }}>
          {timeStr || 'Loading time…'}
        </p>
      </div>

      <div className="flex items-center gap-2">
        {/* Search */}
        <div className="relative hidden md:block">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2"
            style={{ color: 'var(--muted-foreground)' }}
          />
          <input
            type="text"
            placeholder="Search incidents, corridors…"
            className="input-field pl-8 w-60 text-xs py-2"
          />
        </div>

        {/* Refresh */}
        <button
          onClick={handleRefresh}
          className="btn-secondary p-2.5"
          aria-label="Refresh dashboard data"
          title="Refresh dashboard data"
        >
          <RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} />
        </button>

        {/* Export */}
        <button className="btn-secondary p-2.5" aria-label="Export report" title="Export incident report">
          <Download size={15} />
        </button>

        {/* Notifications */}
        <button
          className="relative btn-secondary p-2.5"
          aria-label="View notifications"
          title="View notifications"
        >
          <Bell size={15} />
          <span
            className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-xs font-bold"
            style={{ background: 'var(--primary)', color: '#fff' }}
          >
            3
          </span>
        </button>

        {/* Date filter */}
        <select
          className="input-field text-xs py-2 w-36"
          defaultValue="today"
          aria-label="Select time range"
        >
          <option value="today">Today</option>
          <option value="7d">Last 7 days</option>
          <option value="30d">Last 30 days</option>
          <option value="custom">Custom range</option>
        </select>
      </div>
    </div>
  );
}
'use client';
import React, { useState } from 'react';
import { Search, Filter, ChevronUp, ChevronDown, Eye, Navigation2, Trash2, ChevronLeft, ChevronRight,  } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';
import EmptyState from '@/components/ui/EmptyState';
import { AlertTriangle } from 'lucide-react';

// BACKEND INTEGRATION POINT:GET /api/incidents?page=1&limit=10&status=active
const incidents = [
  {
    id: 'INC-2851',
    type: 'Multi-vehicle collision',
    location: 'Outer Ring Road, Km 14',
    zone: 'ORR',
    severity: 'critical' as const,
    corridor: 'corridor-active' as const,
    assignedUnits: 'AMB-07, P-14, P-22',
    responseTime: '2.8 min',
    status: 'responding' as const,
    reportedAt: '12:38',
  },
  {
    id: 'INC-2850',
    type: 'Medical emergency',
    location: 'Indiranagar 12th Main',
    zone: 'Indiranagar',
    severity: 'high' as const,
    corridor: 'corridor-active' as const,
    assignedUnits: 'AMB-03',
    responseTime: '4.1 min',
    status: 'responding' as const,
    reportedAt: '12:35',
  },
  {
    id: 'INC-2849',
    type: 'Road obstruction',
    location: 'Whitefield Main Rd, Near ITPL',
    zone: 'Whitefield',
    severity: 'medium' as const,
    corridor: 'corridor-inactive' as const,
    assignedUnits: 'P-09',
    responseTime: '6.2 min',
    status: 'verified' as const,
    reportedAt: '12:31',
  },
  {
    id: 'INC-2848',
    type: 'Pedestrian accident',
    location: 'MG Road, Near Trinity Metro',
    zone: 'Central',
    severity: 'high' as const,
    corridor: 'corridor-active' as const,
    assignedUnits: 'AMB-11, P-05',
    responseTime: '3.4 min',
    status: 'responding' as const,
    reportedAt: '12:28',
  },
  {
    id: 'INC-2847',
    type: 'Vehicle fire',
    location: 'Hebbal Flyover, NH44',
    zone: 'Hebbal',
    severity: 'critical' as const,
    corridor: 'corridor-inactive' as const,
    assignedUnits: 'AMB-02, P-18, P-19',
    responseTime: '5.1 min',
    status: 'verified' as const,
    reportedAt: '12:24',
  },
  {
    id: 'INC-2846',
    type: 'Cardiac arrest — public space',
    location: 'Koramangala Forum Mall',
    zone: 'Koramangala',
    severity: 'critical' as const,
    corridor: 'corridor-active' as const,
    assignedUnits: 'AMB-09',
    responseTime: '4.7 min',
    status: 'responding' as const,
    reportedAt: '12:19',
  },
  {
    id: 'INC-2845',
    type: 'Minor collision',
    location: 'JP Nagar 7th Phase',
    zone: 'JP Nagar',
    severity: 'low' as const,
    corridor: 'corridor-inactive' as const,
    assignedUnits: 'P-03',
    responseTime: '3.9 min',
    status: 'resolved' as const,
    reportedAt: '12:12',
  },
  {
    id: 'INC-2844',
    type: 'Road flooding — blocked lane',
    location: 'Marathahalli Bridge',
    zone: 'Marathahalli',
    severity: 'medium' as const,
    corridor: 'corridor-inactive' as const,
    assignedUnits: 'P-21',
    responseTime: '8.3 min',
    status: 'verified' as const,
    reportedAt: '12:07',
  },
  {
    id: 'INC-2843',
    type: 'Two-wheeler accident',
    location: 'Sarjapur Road, Iblur Junction',
    zone: 'Koramangala',
    severity: 'high' as const,
    corridor: 'corridor-inactive' as const,
    assignedUnits: 'AMB-06, P-12',
    responseTime: '5.8 min',
    status: 'resolved' as const,
    reportedAt: '11:58',
  },
  {
    id: 'INC-2842',
    type: 'Truck breakdown — lane blocked',
    location: 'Tumkur Road, Peenya Junction',
    zone: 'Central',
    severity: 'medium' as const,
    corridor: 'corridor-inactive' as const,
    assignedUnits: 'P-07',
    responseTime: '4.4 min',
    status: 'resolved' as const,
    reportedAt: '11:44',
  },
];

type SortField = 'id' | 'severity' | 'responseTime' | 'reportedAt';
type SortDir = 'asc' | 'desc';

const ITEMS_PER_PAGE_OPTIONS = [5, 10, 20];

export default function IncidentTable() {
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortField, setSortField] = useState<SortField>('reportedAt');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [selected, setSelected] = useState<string[]>([]);
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(5);
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const filtered = incidents.filter((inc) => {
    const matchSearch =
      !search ||
      inc.id.toLowerCase().includes(search.toLowerCase()) ||
      inc.type.toLowerCase().includes(search.toLowerCase()) ||
      inc.location.toLowerCase().includes(search.toLowerCase());
    const matchSeverity = severityFilter === 'all' || inc.severity === severityFilter;
    const matchStatus = statusFilter === 'all' || inc.status === statusFilter;
    return matchSearch && matchSeverity && matchStatus;
  });

  const sorted = [...filtered].sort((a, b) => {
    let cmp = 0;
    if (sortField === 'severity') {
      const order = { critical: 0, high: 1, medium: 2, low: 3 };
      cmp = order[a.severity] - order[b.severity];
    } else if (sortField === 'responseTime') {
      cmp = parseFloat(a.responseTime) - parseFloat(b.responseTime);
    } else if (sortField === 'reportedAt') {
      cmp = a.reportedAt.localeCompare(b.reportedAt);
    } else {
      cmp = a.id.localeCompare(b.id);
    }
    return sortDir === 'asc' ? cmp : -cmp;
  });

  const totalPages = Math.max(1, Math.ceil(sorted.length / perPage));
  const paginated = sorted.slice((page - 1) * perPage, page * perPage);

  const toggleSort = (field: SortField) => {
    if (sortField === field) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortField(field); setSortDir('asc'); }
  };

  const toggleSelect = (id: string) => {
    setSelected((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);
  };

  const toggleAll = () => {
    if (selected.length === paginated.length) setSelected([]);
    else setSelected(paginated.map((i) => i.id));
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ChevronUp size={12} style={{ opacity: 0.3 }} />;
    return sortDir === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />;
  };

  return (
    <div className="card flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-5 border-b" style={{ borderColor: 'var(--border)' }}>
        <div>
          <h3 className="text-base font-semibold text-foreground">Live Incident Registry</h3>
          <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
            {filtered.length} incidents · {incidents.filter((i) => i.status !== 'resolved').length} unresolved
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Search */}
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted-foreground)' }} />
            <input
              type="text"
              placeholder="Search incidents…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="input-field pl-8 py-1.5 text-xs w-44"
            />
          </div>
          {/* Severity filter */}
          <select
            value={severityFilter}
            onChange={(e) => { setSeverityFilter(e.target.value); setPage(1); }}
            className="input-field text-xs py-1.5 w-32"
            aria-label="Filter by severity"
          >
            <option value="all">All Severity</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="input-field text-xs py-1.5 w-32"
            aria-label="Filter by status"
          >
            <option value="all">All Status</option>
            <option value="responding">Responding</option>
            <option value="verified">Verified</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>
      </div>

      {/* Bulk action bar */}
      {selected.length > 0 && (
        <div
          className="flex items-center justify-between px-5 py-2.5 border-b text-sm"
          style={{ background: 'rgba(59,130,246,0.08)', borderColor: 'rgba(59,130,246,0.2)' }}
        >
          <span style={{ color: '#93c5fd' }}>
            {selected.length} incident{selected.length > 1 ? 's' : ''} selected
          </span>
          <div className="flex items-center gap-2">
            <button className="btn-secondary py-1 px-3 text-xs">Assign Units</button>
            <button className="btn-secondary py-1 px-3 text-xs">Activate Corridor</button>
            <button
              className="py-1 px-3 text-xs rounded-lg font-semibold transition-all duration-150"
              style={{ background: 'rgba(239,68,68,0.12)', color: '#fca5a5', border: '1px solid rgba(239,68,68,0.25)' }}
            >
              Mark Resolved
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        {paginated.length === 0 ? (
          <EmptyState
            icon={AlertTriangle}
            title="No incidents match your filters"
            description="Try adjusting the severity or status filters, or clear your search query."
            actionLabel="Clear Filters"
            onAction={() => { setSearch(''); setSeverityFilter('all'); setStatusFilter('all'); }}
          />
        ) : (
          <table className="w-full text-sm min-w-[900px]">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                <th className="px-4 py-3 w-10">
                  <input
                    type="checkbox"
                    className="w-3.5 h-3.5 rounded accent-primary"
                    checked={selected.length === paginated.length && paginated.length > 0}
                    onChange={toggleAll}
                    aria-label="Select all incidents"
                  />
                </th>
                {[
                  { label: 'Incident ID', field: 'id' as SortField, sortable: true },
                  { label: 'Type', field: null, sortable: false },
                  { label: 'Location', field: null, sortable: false },
                  { label: 'Severity', field: 'severity' as SortField, sortable: true },
                  { label: 'Corridor', field: null, sortable: false },
                  { label: 'Assigned Units', field: null, sortable: false },
                  { label: 'Response Time', field: 'responseTime' as SortField, sortable: true },
                  { label: 'Status', field: null, sortable: false },
                  { label: 'Reported', field: 'reportedAt' as SortField, sortable: true },
                  { label: '', field: null, sortable: false },
                ].map((col) => (
                  <th
                    key={`th-${col.label || 'actions'}`}
                    className={`px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider whitespace-nowrap ${col.sortable ? 'cursor-pointer select-none hover:text-foreground' : ''}`}
                    style={{ color: 'var(--muted-foreground)' }}
                    onClick={() => col.sortable && col.field && toggleSort(col.field)}
                  >
                    <span className="flex items-center gap-1">
                      {col.label}
                      {col.sortable && col.field && <SortIcon field={col.field} />}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginated.map((inc) => (
                <tr
                  key={inc.id}
                  className="transition-colors duration-100 incident-row-enter"
                  style={{
                    borderBottom: '1px solid var(--border)',
                    background: hoveredRow === inc.id ? 'rgba(255,255,255,0.03)' : 'transparent',
                  }}
                  onMouseEnter={() => setHoveredRow(inc.id)}
                  onMouseLeave={() => setHoveredRow(null)}
                >
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      className="w-3.5 h-3.5 rounded accent-primary"
                      checked={selected.includes(inc.id)}
                      onChange={() => toggleSelect(inc.id)}
                      aria-label={`Select incident ${inc.id}`}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-mono font-semibold text-xs" style={{ color: 'var(--accent)' }}>
                      {inc.id}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-foreground font-medium text-xs whitespace-nowrap">{inc.type}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="text-xs text-foreground truncate max-w-[180px]" title={inc.location}>{inc.location}</p>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>{inc.zone}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge variant={inc.severity} label={inc.severity.charAt(0).toUpperCase() + inc.severity.slice(1)} />
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge variant={inc.corridor} label={inc.corridor === 'corridor-active' ? 'Active' : 'Inactive'} />
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs font-mono" style={{ color: 'var(--muted-foreground)' }}>
                      {inc.assignedUnits}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className="text-xs font-bold tabular-nums"
                      style={{ color: parseFloat(inc.responseTime) > 5 ? '#fca5a5' : '#4ade80' }}
                    >
                      {inc.responseTime}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge variant={inc.status} label={inc.status.charAt(0).toUpperCase() + inc.status.slice(1)} />
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs tabular-nums" style={{ color: 'var(--muted-foreground)' }}>
                      {inc.reportedAt}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div
                      className="flex items-center gap-1 transition-opacity duration-150"
                      style={{ opacity: hoveredRow === inc.id ? 1 : 0 }}
                    >
                      <button
                        className="p-1.5 rounded-md transition-colors hover:text-foreground"
                        style={{ color: 'var(--muted-foreground)' }}
                        title="View incident details"
                        aria-label={`View details for ${inc.id}`}
                      >
                        <Eye size={14} />
                      </button>
                      <button
                        className="p-1.5 rounded-md transition-colors"
                        style={{ color: 'var(--muted-foreground)' }}
                        title="Activate green corridor for this incident"
                        aria-label={`Activate corridor for ${inc.id}`}
                      >
                        <Navigation2 size={14} />
                      </button>
                      <button
                        className="p-1.5 rounded-md transition-colors"
                        style={{ color: 'var(--muted-foreground)' }}
                        title="Delete incident — this cannot be undone"
                        aria-label={`Delete incident ${inc.id}`}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      <div
        className="flex flex-col sm:flex-row items-center justify-between gap-3 px-5 py-3 border-t"
        style={{ borderColor: 'var(--border)' }}
      >
        <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--muted-foreground)' }}>
          <span>Rows per page:</span>
          <select
            value={perPage}
            onChange={(e) => { setPerPage(Number(e.target.value)); setPage(1); }}
            className="input-field text-xs py-1 w-16"
            aria-label="Rows per page"
          >
            {ITEMS_PER_PAGE_OPTIONS.map((n) => (
              <option key={`perpage-${n}`} value={n}>{n}</option>
            ))}
          </select>
          <span>
            {(page - 1) * perPage + 1}–{Math.min(page * perPage, sorted.length)} of {sorted.length}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="p-1.5 rounded-md transition-colors disabled:opacity-30"
            style={{ color: 'var(--muted-foreground)' }}
            aria-label="Previous page"
          >
            <ChevronLeft size={16} />
          </button>
          {Array.from({ length: totalPages }).map((_, i) => (
            <button
              key={`page-${i + 1}`}
              onClick={() => setPage(i + 1)}
              className="w-7 h-7 rounded-md text-xs font-medium transition-all duration-150"
              style={{
                background: page === i + 1 ? 'var(--primary)' : 'transparent',
                color: page === i + 1 ? '#fff' : 'var(--muted-foreground)',
              }}
              aria-label={`Go to page ${i + 1}`}
              aria-current={page === i + 1 ? 'page' : undefined}
            >
              {i + 1}
            </button>
          ))}
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="p-1.5 rounded-md transition-colors disabled:opacity-30"
            style={{ color: 'var(--muted-foreground)' }}
            aria-label="Next page"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
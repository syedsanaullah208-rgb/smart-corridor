'use client';
import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

// BACKEND INTEGRATION POINT: GET /api/analytics/incident-volume?range=7d
const data = [
  { day: '07 May', critical: 3, high: 7, medium: 11, resolved: 18 },
  { day: '08 May', critical: 2, high: 5, medium: 9, resolved: 14 },
  { day: '09 May', critical: 5, high: 9, medium: 14, resolved: 21 },
  { day: '10 May', critical: 1, high: 4, medium: 8, resolved: 11 },
  { day: '11 May', critical: 4, high: 8, medium: 13, resolved: 19 },
  { day: '12 May', critical: 6, high: 11, medium: 16, resolved: 24 },
  { day: '13 May', critical: 7, high: 9, medium: 12, resolved: 15 },
];

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { color: string; name: string; value: number }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="card px-4 py-3 text-xs space-y-1.5"
      style={{ minWidth: '160px', boxShadow: '0 8px 24px rgba(0,0,0,0.4)' }}
    >
      <p className="font-semibold text-foreground mb-2">{label}</p>
      {payload.map((entry) => (
        <div key={`tt-${entry.name}`} className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-1.5" style={{ color: entry.color }}>
            <span className="w-2 h-2 rounded-full" style={{ background: entry.color }} />
            {entry.name}
          </span>
          <span className="font-bold tabular-nums text-foreground">{entry.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function IncidentVolumeChart() {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-base font-semibold text-foreground">Incident Volume</h3>
          <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
            Last 7 days by severity
          </p>
        </div>
        <select
          className="input-field text-xs py-1.5 w-28"
          defaultValue="7d"
          aria-label="Select chart range"
        >
          <option value="7d">Last 7 days</option>
          <option value="30d">Last 30 days</option>
        </select>
      </div>

      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={data} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
          <defs>
            <linearGradient id="gradCritical" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="gradHigh" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#f97316" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#f97316" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="gradResolved" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#22c55e" stopOpacity={0.25} />
              <stop offset="95%" stopColor="#22c55e" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis
            dataKey="day"
            tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: '11px', color: 'var(--muted-foreground)', paddingTop: '12px' }}
          />
          <Area
            type="monotone"
            dataKey="resolved"
            name="Resolved"
            stroke="#22c55e"
            strokeWidth={2}
            fill="url(#gradResolved)"
          />
          <Area
            type="monotone"
            dataKey="high"
            name="High"
            stroke="#f97316"
            strokeWidth={2}
            fill="url(#gradHigh)"
          />
          <Area
            type="monotone"
            dataKey="critical"
            name="Critical"
            stroke="#ef4444"
            strokeWidth={2}
            fill="url(#gradCritical)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
'use client';
import React from 'react';
import {
  AlertTriangle,
  Navigation2,
  Ambulance,
  Building2,
  Shield,
  Activity,
} from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const kpis = [
  {
    id: 'kpi-incidents',
    label: 'Active Incidents',
    value: '7',
    sub: '+2 in last 60 min',
    icon: AlertTriangle,
    color: '#fca5a5',
    bg: 'rgba(239,68,68,0.1)',
    border: 'rgba(239,68,68,0.25)',
    trend: 'up',
    trendLabel: '↑ 40% vs yesterday',
    alert: true,
    span: 'col-span-1 md:col-span-2',
    hero: true,
  },
  {
    id: 'kpi-corridors',
    label: 'Corridors Active',
    value: '3',
    sub: '1 critical zone',
    icon: Navigation2,
    color: '#4ade80',
    bg: 'rgba(34,197,94,0.08)',
    border: 'rgba(34,197,94,0.2)',
    trend: 'neutral',
    trendLabel: 'MG Rd, NH48, ORR',
    alert: false,
    span: 'col-span-1',
    hero: false,
  },
  {
    id: 'kpi-ambulances',
    label: 'Ambulances En Route',
    value: '11',
    sub: '3 available at base',
    icon: Ambulance,
    color: '#93c5fd',
    bg: 'rgba(59,130,246,0.08)',
    border: 'rgba(59,130,246,0.2)',
    trend: 'up',
    trendLabel: '↑ 2 dispatched 8 min ago',
    alert: false,
    span: 'col-span-1',
    hero: false,
  },
  {
    id: 'kpi-icu',
    label: 'ICU Beds Available',
    value: '42%',
    sub: 'Apollo: 8% · Fortis: 61%',
    icon: Building2,
    color: '#fcd34d',
    bg: 'rgba(245,158,11,0.1)',
    border: 'rgba(245,158,11,0.3)',
    trend: 'down',
    trendLabel: '↓ 18% from morning',
    alert: true,
    span: 'col-span-1',
    hero: false,
  },
  {
    id: 'kpi-police',
    label: 'Police Units Deployed',
    value: '24',
    sub: '6 on corridor duty',
    icon: Shield,
    color: '#c4b5fd',
    bg: 'rgba(139,92,246,0.08)',
    border: 'rgba(139,92,246,0.2)',
    trend: 'neutral',
    trendLabel: '18 on patrol',
    alert: false,
    span: 'col-span-1',
    hero: false,
  },
  {
    id: 'kpi-congestion',
    label: 'City Congestion Index',
    value: '7.2',
    sub: 'High — rush hour peak',
    icon: Activity,
    color: '#fdba74',
    bg: 'rgba(249,115,22,0.08)',
    border: 'rgba(249,115,22,0.2)',
    trend: 'up',
    trendLabel: '↑ 1.4 in 30 min',
    alert: true,
    span: 'col-span-1',
    hero: false,
  },
];

export default function KpiBentoGrid() {
  return (
    // 4-col grid: hero spans 2 cols (row 1 col 1-2) + 2 regular (row 1 col 3-4)
    // row 2: 4 regular cards
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {kpis?.map((kpi) => {
        const Icon = kpi?.icon;
        return (
          <div
            key={kpi?.id}
            className={`card p-5 flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 ${kpi?.span} ${kpi?.alert ? 'alert-pulse' : ''}`}
            style={{
              background: kpi?.bg,
              borderColor: kpi?.border,
              minHeight: kpi?.hero ? '140px' : '120px',
            }}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <p
                  className="text-xs font-semibold uppercase tracking-wider mb-0.5"
                  style={{ color: kpi?.color, opacity: 0.8 }}
                >
                  {kpi?.label}
                </p>
                {kpi?.alert && (
                  <span
                    className="text-xs px-1.5 py-0.5 rounded-full font-semibold"
                    style={{ background: 'rgba(239,68,68,0.2)', color: '#fca5a5' }}
                  >
                    ⚠ Alert
                  </span>
                )}
              </div>
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: `${kpi?.color}20` }}
              >
                <Icon size={18} style={{ color: kpi?.color }} />
              </div>
            </div>
            <div>
              <div
                className={`font-bold tabular-nums mb-1 ${kpi?.hero ? 'text-5xl' : 'text-3xl'}`}
                style={{ color: kpi?.color }}
              >
                {kpi?.value}
              </div>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                {kpi?.sub}
              </p>
              <p
                className="text-xs mt-1 font-medium"
                style={{
                  color:
                    kpi?.trend === 'up'
                      ? kpi?.alert
                        ? '#fca5a5' :'#4ade80'
                      : kpi?.trend === 'down' ?'#fca5a5' :'var(--muted-foreground)',
                }}
              >
                {kpi?.trendLabel}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
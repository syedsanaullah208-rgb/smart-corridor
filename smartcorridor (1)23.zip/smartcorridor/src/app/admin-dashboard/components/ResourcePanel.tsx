'use client';
import React from 'react';
import { Building2, Shield, Activity } from 'lucide-react';

// BACKEND INTEGRATION POINT: GET /api/resources/summary
const hospitals = [
  { id: 'hosp-apollo', name: 'Apollo Hospital', icuFree: 8, icuTotal: 100, erFree: 12, ambulancesActive: 4 },
  { id: 'hosp-fortis', name: 'Fortis Cunningham', icuFree: 61, icuTotal: 80, erFree: 22, ambulancesActive: 2 },
  { id: 'hosp-manipal', name: 'Manipal Hospitals', icuFree: 34, icuTotal: 60, erFree: 9, ambulancesActive: 3 },
  { id: 'hosp-narayana', name: 'Narayana Health', icuFree: 47, icuTotal: 90, erFree: 18, ambulancesActive: 2 },
];

const policeZones = [
  { id: 'zone-central', zone: 'Central', total: 8, deployed: 6, onCorridor: 2 },
  { id: 'zone-orr', zone: 'Outer Ring Road', total: 6, deployed: 6, onCorridor: 3 },
  { id: 'zone-whitefield', zone: 'Whitefield', total: 5, deployed: 3, onCorridor: 1 },
  { id: 'zone-koramangala', zone: 'Koramangala', total: 4, deployed: 4, onCorridor: 0 },
];

function ProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div className="w-full rounded-full h-1.5" style={{ background: 'var(--muted)' }}>
      <div
        className="h-1.5 rounded-full transition-all duration-500"
        style={{ width: `${pct}%`, background: color }}
      />
    </div>
  );
}

export default function ResourcePanel() {
  return (
    <div className="card">
      <div
        className="flex items-center gap-2 px-5 py-4 border-b"
        style={{ borderColor: 'var(--border)' }}
      >
        <Activity size={16} style={{ color: 'var(--accent)' }} />
        <h3 className="text-sm font-semibold text-foreground">Resource Status</h3>
      </div>

      {/* Hospitals */}
      <div className="px-5 pt-4 pb-3">
        <div className="flex items-center gap-2 mb-3">
          <Building2 size={13} style={{ color: 'var(--muted-foreground)' }} />
          <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>
            Hospital ICU Capacity
          </p>
        </div>
        <div className="space-y-3">
          {hospitals.map((h) => {
            const icuPct = Math.round((h.icuFree / h.icuTotal) * 100);
            const color = icuPct < 15 ? '#ef4444' : icuPct < 40 ? '#f59e0b' : '#22c55e';
            return (
              <div key={h.id}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-foreground font-medium truncate max-w-[140px]" title={h.name}>
                    {h.name}
                  </span>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs tabular-nums font-bold" style={{ color }}>
                      {icuPct}% free
                    </span>
                    <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                      ({h.icuFree}/{h.icuTotal})
                    </span>
                  </div>
                </div>
                <ProgressBar value={h.icuFree} max={h.icuTotal} color={color} />
                <p className="text-xs mt-1" style={{ color: 'var(--muted-foreground)' }}>
                  {h.erFree} ER beds free · {h.ambulancesActive} ambulances active
                </p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="border-t mx-5" style={{ borderColor: 'var(--border)' }} />

      {/* Police Zones */}
      <div className="px-5 pt-3 pb-4">
        <div className="flex items-center gap-2 mb-3">
          <Shield size={13} style={{ color: 'var(--muted-foreground)' }} />
          <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>
            Police Unit Deployment
          </p>
        </div>
        <div className="space-y-2.5">
          {policeZones.map((z) => {
            const deployPct = Math.round((z.deployed / z.total) * 100);
            return (
              <div key={z.id}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-foreground font-medium">{z.zone}</span>
                  <span className="text-xs tabular-nums" style={{ color: deployPct === 100 ? '#fca5a5' : '#4ade80' }}>
                    {z.deployed}/{z.total} deployed
                  </span>
                </div>
                <ProgressBar value={z.deployed} max={z.total} color={deployPct === 100 ? '#ef4444' : '#3b82f6'} />
                {z.onCorridor > 0 && (
                  <p className="text-xs mt-0.5" style={{ color: '#4ade80' }}>
                    {z.onCorridor} on corridor duty
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
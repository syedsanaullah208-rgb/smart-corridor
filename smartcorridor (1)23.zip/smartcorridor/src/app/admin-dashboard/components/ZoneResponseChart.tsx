'use client';
import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine,
} from 'recharts';

// BACKEND INTEGRATION POINT: GET /api/analytics/response-times?groupBy=zone
const data = [
  { zone: 'Central', avgMin: 3.2, target: 5 },
  { zone: 'Whitefield', avgMin: 6.8, target: 5 },
  { zone: 'Indiranagar', avgMin: 4.1, target: 5 },
  { zone: 'Koramangala', avgMin: 5.6, target: 5 },
  { zone: 'ORR', avgMin: 7.4, target: 5 },
  { zone: 'Hebbal', avgMin: 4.9, target: 5 },
  { zone: 'Marathahalli', avgMin: 8.1, target: 5 },
  { zone: 'JP Nagar', avgMin: 3.7, target: 5 },
];

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  const val = payload[0].value;
  const overTarget = val > 5;
  return (
    <div className="card px-3 py-2.5 text-xs" style={{ boxShadow: '0 8px 24px rgba(0,0,0,0.4)' }}>
      <p className="font-semibold text-foreground mb-1">{label} Zone</p>
      <p style={{ color: overTarget ? '#fca5a5' : '#4ade80' }}>
        Avg Response: <strong>{val} min</strong>
      </p>
      <p style={{ color: 'var(--muted-foreground)' }}>Target: 5.0 min</p>
      {overTarget && (
        <p className="mt-1 font-semibold" style={{ color: '#fca5a5' }}>
          ⚠ {(val - 5).toFixed(1)} min over SLA
        </p>
      )}
    </div>
  );
};

export default function ZoneResponseChart() {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-base font-semibold text-foreground">Response Time by Zone</h3>
          <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
            Avg minutes to first responder arrival · SLA: 5 min
          </p>
        </div>
        <div
          className="flex items-center gap-3 text-xs"
          style={{ color: 'var(--muted-foreground)' }}
        >
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full" style={{ background: '#4ade80' }} />
            Within SLA
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full" style={{ background: '#ef4444' }} />
            Over SLA
          </span>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} margin={{ top: 4, right: 4, left: -16, bottom: 0 }} barSize={24}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis
            dataKey="zone"
            tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
            axisLine={false}
            tickLine={false}
            unit=" m"
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine
            y={5}
            stroke="#f59e0b"
            strokeDasharray="4 4"
            strokeWidth={1.5}
            label={{ value: 'SLA 5m', fill: '#fcd34d', fontSize: 10, position: 'right' }}
          />
          <Bar dataKey="avgMin" name="Avg Response" radius={[4, 4, 0, 0]}>
            {data.map((entry) => (
              <Cell
                key={`bar-zone-${entry.zone}`}
                fill={entry.avgMin > 5 ? '#ef4444' : '#22c55e'}
                fillOpacity={0.8}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
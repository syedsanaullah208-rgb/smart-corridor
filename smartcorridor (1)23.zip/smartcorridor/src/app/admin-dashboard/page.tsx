import React from 'react';
import AppLayout from '@/components/AppLayout';
import AdminTopbar from './components/AdminTopbar';
import KpiBentoGrid from './components/KpiBentoGrid';
import IncidentTable from './components/IncidentTable';
import AdminChartsRow from './components/AdminChartsRow';
import ActivityFeed from './components/ActivityFeed';
import ResourcePanel from './components/ResourcePanel';

export default function AdminDashboardPage() {
  return (
    <AppLayout activeRoute="/admin-dashboard">
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-8 xl:px-10 py-6 space-y-6">
        <AdminTopbar />
        <KpiBentoGrid />
        <AdminChartsRow />
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2">
            <IncidentTable />
          </div>
          <div className="space-y-6">
            <ActivityFeed />
            <ResourcePanel />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
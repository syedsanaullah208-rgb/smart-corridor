import React from 'react';
import Link from 'next/link';
import { Siren, ArrowRight } from 'lucide-react';

export default function HomeCTA() {
  return (
    <section className="py-20">
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-10">
        <div
          className="rounded-2xl p-12 text-center relative overflow-hidden border"
          style={{ background: 'var(--card)', borderColor: 'rgba(239,68,68,0.2)' }}
        >
          <div className="absolute inset-0 blob-primary pointer-events-none" />
          <div className="relative z-10">
            <div
              className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-6"
              style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)' }}
            >
              <Siren size={28} style={{ color: '#fca5a5' }} />
            </div>
            <h2 className="text-hero-md font-bold text-foreground mb-4">
              Deploy SmartCorridor in Your City
            </h2>
            <p
              className="text-base max-w-xl mx-auto mb-8"
              style={{ color: 'var(--muted-foreground)' }}
            >
              Join 14 cities already saving lives with coordinated emergency response.
              Request a pilot deployment or access the live demo environment.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Link href="/sign-up-login-screen" className="btn-primary px-8 py-3 text-base">
                Request City Deployment <ArrowRight size={16} />
              </Link>
              <Link href="/admin-dashboard" className="btn-secondary px-8 py-3 text-base">
                Explore Live Demo
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
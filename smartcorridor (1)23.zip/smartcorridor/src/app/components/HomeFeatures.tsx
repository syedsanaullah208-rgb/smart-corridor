import React from 'react';
import Link from 'next/link';
import {
  LayoutDashboard,
  Building2,
  Shield,
  Users,
  Navigation2,
  AlertTriangle,
  MapPin,
  Activity,
  Clock,
  Ambulance,
  Radio,
  BarChart3,
  ArrowRight,
} from 'lucide-react';

const roles = [
  {
    id: 'role-admin',
    role: 'Admin',
    title: 'City-Wide Emergency Operations',
    description:
      'Full situational awareness across all incidents, corridors, hospital capacity, and unit deployment from a single command dashboard.',
    icon: LayoutDashboard,
    color: '#ef4444',
    bg: 'rgba(239,68,68,0.08)',
    border: 'rgba(239,68,68,0.2)',
    features: [
      { icon: AlertTriangle, text: 'Real-time incident management with severity triage' },
      { icon: Navigation2, text: 'Auto green corridor activation and monitoring' },
      { icon: BarChart3, text: 'Response time analytics by zone and unit type' },
      { icon: MapPin, text: 'Accident spot mapping with live GPS overlays' },
    ],
  },
  {
    id: 'role-hospital',
    role: 'Hospital',
    title: 'Resource & Ambulance Command',
    description:
      'Track ICU bed availability, manage ambulance dispatch, receive incoming patient alerts, and coordinate with police for corridor clearance.',
    icon: Building2,
    color: '#3b82f6',
    bg: 'rgba(59,130,246,0.08)',
    border: 'rgba(59,130,246,0.2)',
    features: [
      { icon: Activity, text: 'Live ICU, ER, and general ward bed tracking' },
      { icon: Ambulance, text: 'Ambulance GPS tracking with ETA to incident' },
      { icon: Radio, text: 'Emergency incoming patient pre-alerts' },
      { icon: Clock, text: 'Response time SLA monitoring per ambulance' },
    ],
  },
  {
    id: 'role-police',
    role: 'Police',
    title: 'Traffic Control & Incident Response',
    description:
      'Monitor signal states, receive incident assignments, coordinate corridor clearance, and log intervention actions in real time.',
    icon: Shield,
    color: '#f59e0b',
    bg: 'rgba(245,158,11,0.08)',
    border: 'rgba(245,158,11,0.2)',
    features: [
      { icon: Navigation2, text: 'Signal override requests for green corridors' },
      { icon: MapPin, text: 'Zone-based congestion monitoring and alerts' },
      { icon: AlertTriangle, text: 'Incident assignment with priority routing' },
      { icon: BarChart3, text: 'Intervention log with timestamp and outcome' },
    ],
  },
  {
    id: 'role-citizen',
    role: 'Citizen',
    title: 'Alerts & Alternate Routes',
    description:
      'Stay informed about nearby incidents, active corridor zones, and get alternate route suggestions to avoid emergency vehicle paths.',
    icon: Users,
    color: '#22c55e',
    bg: 'rgba(34,197,94,0.08)',
    border: 'rgba(34,197,94,0.2)',
    features: [
      { icon: Radio, text: 'Push alerts for incidents within 3 km radius' },
      { icon: Navigation2, text: 'Alternate route suggestions during corridors' },
      { icon: MapPin, text: 'Live congestion heatmap for your commute zone' },
      { icon: Clock, text: 'Estimated delay notifications for active zones' },
    ],
  },
];

export default function HomeFeatures() {
  return (
    <section id="features" className="py-20">
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-10">
        <div className="text-center mb-14">
          <p
            className="text-xs font-semibold uppercase tracking-widest mb-3"
            style={{ color: 'var(--primary)' }}
          >
            Role-Based Platform
          </p>
          <h2 className="text-hero-md font-bold text-foreground mb-4">
            One Platform, Four Command Centers
          </h2>
          <p className="text-base max-w-xl mx-auto" style={{ color: 'var(--muted-foreground)' }}>
            Every stakeholder in the emergency chain gets a purpose-built view — no noise,
            only the data that matters for their role.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {roles?.map((role) => {
            const RoleIcon = role?.icon;
            return (
              <div
                key={role?.id}
                className="card p-6 flex flex-col group hover:border-opacity-60 transition-all duration-200"
                style={{ borderColor: role?.border }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: role?.bg, border: `1px solid ${role?.border}` }}
                >
                  <RoleIcon size={22} style={{ color: role?.color }} />
                </div>
                <span
                  className="text-xs font-semibold uppercase tracking-wider mb-2"
                  style={{ color: role?.color }}
                >
                  {role?.role}
                </span>
                <h3 className="text-base font-bold text-foreground mb-3">{role?.title}</h3>
                <p className="text-sm leading-relaxed mb-5" style={{ color: 'var(--muted-foreground)' }}>
                  {role?.description}
                </p>
                <ul className="space-y-2.5 flex-1">
                  {role?.features?.map((feat) => {
                    const FeatIcon = feat?.icon;
                    return (
                      <li
                        key={`feat-${role?.id}-${feat?.text?.slice(0, 20)}`}
                        className="flex items-start gap-2.5 text-sm"
                        style={{ color: 'var(--muted-foreground)' }}
                      >
                        <FeatIcon size={14} className="shrink-0 mt-0.5" style={{ color: role?.color }} />
                        {feat?.text}
                      </li>
                    );
                  })}
                </ul>
                <Link
                  href="/sign-up-login-screen"
                  className="mt-6 flex items-center gap-1.5 text-sm font-semibold transition-all duration-150 group-hover:gap-2.5"
                  style={{ color: role?.color }}
                >
                  Access {role?.role} Portal <ArrowRight size={14} />
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
import React from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import { Shield, Mail, Phone } from 'lucide-react';

const footerLinks = {
  Platform: [
    { label: 'Admin Portal', href: '/admin-dashboard' },
    { label: 'Hospital Dashboard', href: '/sign-up-login-screen' },
    { label: 'Police Dashboard', href: '/sign-up-login-screen' },
    { label: 'Citizen App', href: '/sign-up-login-screen' },
  ],
  Resources: [
    { label: 'API Documentation', href: '#' },
    { label: 'Deployment Guide', href: '#' },
    { label: 'SLA Standards', href: '#' },
    { label: 'Training Portal', href: '#' },
  ],
  Legal: [
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
    { label: 'Data Processing', href: '#' },
    { label: 'Security', href: '#' },
  ],
};

export default function HomeFooter() {
  return (
    <footer
      className="border-t py-12"
      style={{ borderColor: 'var(--border)', background: 'var(--card)' }}
    >
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-10 mb-10">
          {/* Brand */}
          <div className="xl:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <AppLogo size={36} />
              <span className="font-bold text-lg text-foreground">SmartCorridor</span>
            </Link>
            <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--muted-foreground)' }}>
              Real-time emergency response coordination for municipalities, hospitals, and
              police departments. Trusted by emergency services across India.
            </p>
            <div className="space-y-2">
              <a
                href="mailto:ops@smartcorridor.gov.in"
                className="flex items-center gap-2 text-sm transition-colors hover:text-foreground"
                style={{ color: 'var(--muted-foreground)' }}
              >
                <Mail size={14} />
                ops@smartcorridor.gov.in
              </a>
              <a
                href="tel:+911800-CORRIDOR"
                className="flex items-center gap-2 text-sm transition-colors hover:text-foreground"
                style={{ color: 'var(--muted-foreground)' }}
              >
                <Phone size={14} />
                1800-CORRIDOR (Emergency Ops Line)
              </a>
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks)?.map(([section, links]) => (
            <div key={`footer-section-${section}`}>
              <h4
                className="text-xs font-semibold uppercase tracking-widest mb-4"
                style={{ color: 'var(--muted-foreground)' }}
              >
                {section}
              </h4>
              <ul className="space-y-2.5">
                {links?.map((link) => (
                  <li key={`footer-link-${link?.label}`}>
                    <Link
                      href={link?.href}
                      className="text-sm transition-colors hover:text-foreground"
                      style={{ color: 'var(--muted-foreground)' }}
                    >
                      {link?.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div
          className="pt-6 border-t flex flex-col md:flex-row items-center justify-between gap-4"
          style={{ borderColor: 'var(--border)' }}
        >
          <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
            © 2026 SmartCorridor — National Emergency Management Initiative. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--muted-foreground)' }}>
            <Shield size={12} />
            ISO 27001 Certified · MHA Approved · CERT-In Compliant
          </div>
        </div>
      </div>
    </footer>
  );
}
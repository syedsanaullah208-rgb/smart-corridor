'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowRight, Radio, Navigation2, AlertTriangle } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const liveItems = [
  { id: 'live-1', text: 'Green corridor activated — MG Road to City Hospital', type: 'corridor' },
  { id: 'live-2', text: 'Incident INC-2847 cleared — NH48 Junction restored', type: 'resolved' },
  { id: 'live-3', text: 'Ambulance AMB-09 en route — ETA 4 min', type: 'ambulance' },
  { id: 'live-4', text: 'Police Unit P-14 deployed — Outer Ring Road', type: 'police' },
  { id: 'live-5', text: 'ICU capacity alert — Apollo Hospital 92% utilised', type: 'alert' },
];

export default function HomeHero() {
  const [tickerIndex, setTickerIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTickerIndex((i) => (i + 1) % liveItems?.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  const current = liveItems?.[tickerIndex];

  return (
    <section className="relative pt-24 pb-20 overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-20 left-1/4 w-96 h-96 blob-primary pointer-events-none" />
      <div className="absolute top-40 right-1/4 w-80 h-80 blob-accent pointer-events-none" />
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-10 relative z-10">
        {/* Live ticker */}
        <div className="flex items-center justify-center mb-8">
          <div
            className="flex items-center gap-3 px-4 py-2 rounded-full border text-sm"
            style={{
              background: 'rgba(239,68,68,0.08)',
              borderColor: 'rgba(239,68,68,0.25)',
            }}
          >
            <span className="flex items-center gap-1.5" style={{ color: '#fca5a5' }}>
              <Radio size={13} className="pulse-dot" />
              <span className="font-semibold text-xs uppercase tracking-wider">Live</span>
            </span>
            <span
              className="text-xs transition-all duration-500"
              style={{ color: 'var(--muted-foreground)' }}
              key={current?.id}
            >
              {current?.text}
            </span>
          </div>
        </div>

        {/* Headline */}
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-hero-xl font-bold text-foreground mb-6 leading-tight">
            Emergency Response,{' '}
            <span
              className="relative"
              style={{
                background: 'linear-gradient(135deg, #ef4444, #f97316)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              Coordinated
            </span>{' '}
            in Real Time
          </h1>
          <p
            className="text-lg leading-relaxed max-w-2xl mx-auto mb-8"
            style={{ color: 'var(--muted-foreground)' }}
          >
            SmartCorridor connects hospitals, police units, and emergency services into a
            single operational platform — clearing green corridors, tracking ambulances,
            and resolving incidents faster than ever.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/sign-up-login-screen" className="btn-primary px-6 py-3 text-base">
              Access Emergency Portal
              <ArrowRight size={16} />
            </Link>
            <Link href="/admin-dashboard" className="btn-secondary px-6 py-3 text-base">
              View Live Dashboard
            </Link>
          </div>
        </div>

        {/* Feature pills */}
        <div className="flex flex-wrap items-center justify-center gap-3 mt-12">
          {[
            { icon: Navigation2, label: 'Auto Green Corridors', color: '#4ade80' },
            { icon: AlertTriangle, label: 'Live Incident Tracking', color: '#fca5a5' },
            { icon: Radio, label: 'Real-Time GPS Dispatch', color: '#93c5fd' },
          ]?.map((pill) => {
            const Icon = pill?.icon;
            return (
              <div
                key={`hero-pill-${pill?.label}`}
                className="flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-medium"
                style={{
                  background: 'var(--card)',
                  borderColor: 'var(--border)',
                  color: pill?.color,
                }}
              >
                <Icon size={14} />
                {pill?.label}
              </div>
            );
          })}
        </div>

        {/* Mock dashboard preview strip */}
        <div
          className="mt-16 rounded-2xl border overflow-hidden"
          style={{
            background: 'var(--card)',
            borderColor: 'var(--border)',
            boxShadow: '0 24px 64px rgba(0,0,0,0.5)',
          }}
        >
          {/* Window chrome */}
          <div
            className="flex items-center gap-2 px-4 py-3 border-b"
            style={{ background: 'var(--muted)', borderColor: 'var(--border)' }}
          >
            <span className="w-3 h-3 rounded-full" style={{ background: '#ef4444' }} />
            <span className="w-3 h-3 rounded-full" style={{ background: '#f59e0b' }} />
            <span className="w-3 h-3 rounded-full" style={{ background: '#22c55e' }} />
            <span
              className="ml-4 text-xs font-mono"
              style={{ color: 'var(--muted-foreground)' }}
            >
              smartcorridor.gov.in/admin-dashboard
            </span>
            <span
              className="ml-auto flex items-center gap-1.5 text-xs font-semibold"
              style={{ color: '#4ade80' }}
            >
              <span className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#4ade80' }} />
              LIVE
            </span>
          </div>
          {/* Dashboard preview rows */}
          <div className="grid grid-cols-4 gap-3 p-4">
            {[
              { label: 'Active Incidents', value: '7', color: '#fca5a5', bg: 'rgba(239,68,68,0.1)' },
              { label: 'Corridors Active', value: '3', color: '#4ade80', bg: 'rgba(34,197,94,0.1)' },
              { label: 'Ambulances En Route', value: '11', color: '#93c5fd', bg: 'rgba(59,130,246,0.1)' },
              { label: 'ICU Beds Free', value: '42%', color: '#fcd34d', bg: 'rgba(245,158,11,0.1)' },
            ]?.map((card) => (
              <div
                key={`preview-${card?.label}`}
                className="rounded-xl p-3 border"
                style={{ background: card?.bg, borderColor: card?.color + '30' }}
              >
                <p className="text-xs mb-1" style={{ color: 'var(--muted-foreground)' }}>
                  {card?.label}
                </p>
                <p className="text-2xl font-bold tabular-nums" style={{ color: card?.color }}>
                  {card?.value}
                </p>
              </div>
            ))}
          </div>
          {/* Fake table rows */}
          <div className="px-4 pb-4 space-y-2">
            {[
              { id: 'INC-2851', type: 'Multi-vehicle collision', loc: 'Outer Ring Road, Km 14', sev: 'Critical', status: 'Corridor Active' },
              { id: 'INC-2850', type: 'Medical emergency', loc: 'Indiranagar 12th Main', sev: 'High', status: 'Responding' },
              { id: 'INC-2849', type: 'Road obstruction', loc: 'Whitefield Main Rd', sev: 'Medium', status: 'Verified' },
            ]?.map((row) => (
              <div
                key={`preview-row-${row?.id}`}
                className="flex items-center gap-4 px-3 py-2 rounded-lg text-xs"
                style={{ background: 'var(--muted)' }}
              >
                <span className="font-mono font-semibold text-accent">{row?.id}</span>
                <span className="flex-1 text-foreground truncate">{row?.type}</span>
                <span style={{ color: 'var(--muted-foreground)' }} className="truncate hidden sm:block">
                  {row?.loc}
                </span>
                <span
                  className="px-2 py-0.5 rounded-full font-semibold"
                  style={{
                    background: row?.sev === 'Critical' ? 'rgba(239,68,68,0.15)' : row?.sev === 'High' ? 'rgba(249,115,22,0.15)' : 'rgba(245,158,11,0.15)',
                    color: row?.sev === 'Critical' ? '#fca5a5' : row?.sev === 'High' ? '#fdba74' : '#fcd34d',
                  }}
                >
                  {row?.sev}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
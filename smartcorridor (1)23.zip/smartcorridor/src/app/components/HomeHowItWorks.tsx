import React from 'react';
import { AlertTriangle, Navigation2, Ambulance, CheckCircle } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const steps = [
  {
    id: 'step-1',
    step: '01',
    icon: AlertTriangle,
    title: 'Incident Reported',
    description:
      'An accident or emergency is reported via police patrol, citizen app, or automated sensor. SmartCorridor validates and classifies severity within seconds.',
    color: '#ef4444',
    bg: 'rgba(239,68,68,0.1)',
  },
  {
    id: 'step-2',
    step: '02',
    icon: Navigation2,
    title: 'Green Corridor Activated',
    description:
      'The optimal route from the nearest ambulance to the best hospital is computed. Traffic signals along the route are overridden to create an unobstructed corridor.',
    color: '#22c55e',
    bg: 'rgba(34,197,94,0.1)',
  },
  {
    id: 'step-3',
    step: '03',
    icon: Ambulance,
    title: 'Units Dispatched',
    description:
      'Ambulances and police units receive GPS-guided dispatch assignments. Hospital pre-alert is sent with patient condition and ETA for immediate preparation.',
    color: '#3b82f6',
    bg: 'rgba(59,130,246,0.1)',
  },
  {
    id: 'step-4',
    step: '04',
    icon: CheckCircle,
    title: 'Incident Resolved',
    description:
      'Response time is logged, corridor is deactivated, signals return to normal. All data feeds into analytics for continuous improvement of city response capacity.',
    color: '#f59e0b',
    bg: 'rgba(245,158,11,0.1)',
  },
];

export default function HomeHowItWorks() {
  return (
    <section
      id="how-it-works"
      className="py-20 border-y"
      style={{ borderColor: 'var(--border)', background: 'var(--card)' }}
    >
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-10">
        <div className="text-center mb-14">
          <p
            className="text-xs font-semibold uppercase tracking-widest mb-3"
            style={{ color: 'var(--accent)' }}
          >
            Emergency Workflow
          </p>
          <h2 className="text-hero-md font-bold text-foreground mb-4">
            From Incident to Resolution in Minutes
          </h2>
          <p className="text-base max-w-xl mx-auto" style={{ color: 'var(--muted-foreground)' }}>
            SmartCorridor automates the coordination chain so responders focus on saving lives,
            not navigating bureaucracy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 relative">
          {/* Connector line (desktop) */}
          <div
            className="absolute top-10 left-[12.5%] right-[12.5%] h-0.5 hidden xl:block"
            style={{ background: 'var(--border)' }}
          />

          {steps?.map((step, idx) => {
            const Icon = step?.icon;
            return (
              <div key={step?.id} className="relative flex flex-col items-center text-center">
                {/* Step number */}
                <div
                  className="relative z-10 w-20 h-20 rounded-2xl flex items-center justify-center mb-6 border"
                  style={{ background: step?.bg, borderColor: step?.color + '40' }}
                >
                  <Icon size={28} style={{ color: step?.color }} />
                  <span
                    className="absolute -top-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{ background: step?.color, color: '#fff' }}
                  >
                    {idx + 1}
                  </span>
                </div>
                <h3 className="text-base font-bold text-foreground mb-3">{step?.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
                  {step?.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
'use client';
import React, { useEffect, useRef, useState } from 'react';

const stats = [
  { id: 'stat-cities', value: 14, suffix: '', label: 'Cities Deployed', sublabel: 'Across 6 states' },
  { id: 'stat-incidents', value: 98400, suffix: '+', label: 'Incidents Managed', sublabel: 'Since 2023 launch' },
  { id: 'stat-response', value: 3.8, suffix: ' min', label: 'Avg Response Time', sublabel: 'Down from 8.2 min' },
  { id: 'stat-corridors', value: 99.1, suffix: '%', label: 'Corridor Success Rate', sublabel: 'Unobstructed clearance' },
];

function useCountUp(target: number, duration = 1800, started = false) {
  const [current, setCurrent] = useState(0);
  useEffect(() => {
    if (!started) return;
    const isDecimal = target % 1 !== 0;
    const steps = 60;
    const stepValue = target / steps;
    let step = 0;
    const interval = setInterval(() => {
      step++;
      const next = Math.min(step * stepValue, target);
      setCurrent(isDecimal ? Math.round(next * 10) / 10 : Math.floor(next));
      if (step >= steps) clearInterval(interval);
    }, duration / steps);
    return () => clearInterval(interval);
  }, [target, duration, started]);
  return current;
}

function StatCard({ stat }: { stat: typeof stats[0] }) {
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const value = useCountUp(stat.value, 1600, started);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className="text-center">
      <div className="text-5xl font-bold tabular-nums mb-2" style={{ color: 'var(--primary)' }}>
        {stat.value % 1 !== 0 ? value.toFixed(1) : value.toLocaleString()}
        <span className="text-3xl">{stat.suffix}</span>
      </div>
      <div className="text-base font-semibold text-foreground mb-1">{stat.label}</div>
      <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{stat.sublabel}</div>
    </div>
  );
}

export default function HomeStats() {
  return (
    <section id="stats" className="py-16 border-y" style={{ borderColor: 'var(--border)' }}>
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-10">
          {stats.map((stat) => (
            <StatCard key={stat.id} stat={stat} />
          ))}
        </div>
      </div>
    </section>
  );
}
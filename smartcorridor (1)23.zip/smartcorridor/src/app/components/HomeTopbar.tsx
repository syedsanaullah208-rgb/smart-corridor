'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import { Menu, X, Siren } from 'lucide-react';

const navLinks = [
  { label: 'Platform', href: '#features' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'For Cities', href: '#features' },
  { label: 'Response Stats', href: '#stats' },
];

export default function HomeTopbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 border-b"
      style={{
        background: 'rgba(10,15,30,0.9)',
        backdropFilter: 'blur(12px)',
        borderColor: 'var(--border)',
      }}
    >
      <div className="max-w-screen-2xl mx-auto px-6 lg:px-10 flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <AppLogo size={36} />
          <span className="font-bold text-lg tracking-tight text-foreground">SmartCorridor</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks?.map((link) => (
            <a
              key={`topnav-${link?.label}`}
              href={link?.href}
              className="px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 hover:text-foreground"
              style={{ color: 'var(--muted-foreground)' }}
            >
              {link?.label}
            </a>
          ))}
        </nav>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-3">
          <Link
            href="/sign-up-login-screen"
            className="px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-150 hover:text-foreground"
            style={{ color: 'var(--muted-foreground)' }}
          >
            Sign In
          </Link>
          <Link href="/sign-up-login-screen" className="btn-primary">
            <Siren size={14} />
            Access Portal
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden p-2 rounded-lg"
          style={{ color: 'var(--muted-foreground)' }}
          onClick={() => setMobileOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="md:hidden border-t px-6 py-4 space-y-2"
          style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
        >
          {navLinks?.map((link) => (
            <a
              key={`mobilenav-${link?.label}`}
              href={link?.href}
              className="block px-3 py-2.5 rounded-lg text-sm font-medium transition-colors"
              style={{ color: 'var(--muted-foreground)' }}
              onClick={() => setMobileOpen(false)}
            >
              {link?.label}
            </a>
          ))}
          <div className="pt-2 border-t space-y-2" style={{ borderColor: 'var(--border)' }}>
            <Link
              href="/sign-up-login-screen"
              className="btn-secondary w-full justify-center"
              onClick={() => setMobileOpen(false)}
            >
              Sign In
            </Link>
            <Link
              href="/sign-up-login-screen"
              className="btn-primary w-full justify-center"
              onClick={() => setMobileOpen(false)}
            >
              Access Portal
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
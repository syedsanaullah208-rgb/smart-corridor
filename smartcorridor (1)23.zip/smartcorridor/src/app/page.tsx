import React from 'react';
import HomeHero from './components/HomeHero';
import HomeStats from './components/HomeStats';
import HomeFeatures from './components/HomeFeatures';
import HomeHowItWorks from './components/HomeHowItWorks';
import HomeCTA from './components/HomeCTA';
import HomeTopbar from './components/HomeTopbar';
import HomeFooter from './components/HomeFooter';

export default function HomePage() {
  return (
    <div className="min-h-screen" style={{ background: 'var(--background)' }}>
      <HomeTopbar />
      <HomeHero />
      <HomeStats />
      <HomeFeatures />
      <HomeHowItWorks />
      <HomeCTA />
      <HomeFooter />
    </div>
  );
}
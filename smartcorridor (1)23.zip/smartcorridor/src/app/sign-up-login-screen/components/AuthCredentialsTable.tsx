'use client';
import React from 'react';
import { Copy, LogIn } from 'lucide-react';

interface Credential {
  role: string;
  email: string;
  password: string;
  color: string;
}

const credentials: Credential[] = [
  {
    role: 'Admin',
    email: 'arjun.chakraborty@eoc.smartcorridor.gov.in',
    password: 'Admin@SC2026',
    color: '#ef4444',
  },
  {
    role: 'Hospital',
    email: 'dr.priya.mehta@apolloeoc.in',
    password: 'Hosp@SC2026',
    color: '#3b82f6',
  },
  {
    role: 'Police',
    email: 'insp.ravi.kumar@ksp.gov.in',
    password: 'Police@SC2026',
    color: '#f59e0b',
  },
  {
    role: 'Citizen',
    email: 'meera.nair@gmail.com',
    password: 'Citizen@2026',
    color: '#22c55e',
  },
];

interface AuthCredentialsTableProps {
  onSelect: (email: string, password: string) => void;
}

export default function AuthCredentialsTable({ onSelect }: AuthCredentialsTableProps) {
  const [copied, setCopied] = React.useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(key);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="mt-8">
      <div
        className="rounded-xl border overflow-hidden"
        style={{ borderColor: 'var(--border)', background: 'var(--muted)' }}
      >
        <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border)' }}>
          <p className="text-xs font-semibold" style={{ color: 'var(--muted-foreground)' }}>
            Demo Credentials — click a row to autofill
          </p>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              {['Role', 'Email', 'Password', ''].map((h) => (
                <th
                  key={`cred-header-${h || 'action'}`}
                  className="px-3 py-2 text-left font-semibold uppercase tracking-wider"
                  style={{ color: 'var(--muted-foreground)', fontSize: '10px' }}
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {credentials.map((cred) => (
              <tr
                key={`cred-${cred.role}`}
                className="cursor-pointer transition-colors"
                style={{ borderBottom: '1px solid var(--border)' }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = 'rgba(59,130,246,0.05)')
                }
                onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
              >
                <td className="px-3 py-2.5">
                  <span
                    className="font-semibold"
                    style={{ color: cred.color }}
                  >
                    {cred.role}
                  </span>
                </td>
                <td className="px-3 py-2.5">
                  <span
                    className="font-mono truncate block max-w-[180px]"
                    style={{ color: 'var(--foreground)' }}
                    title={cred.email}
                  >
                    {cred.email}
                  </span>
                </td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono" style={{ color: 'var(--foreground)' }}>
                      {cred.password}
                    </span>
                    <button
                      onClick={() => handleCopy(cred.password, `pw-${cred.role}`)}
                      className="p-0.5 rounded transition-colors hover:text-foreground"
                      style={{ color: 'var(--muted-foreground)' }}
                      aria-label={`Copy ${cred.role} password`}
                    >
                      <Copy size={11} />
                    </button>
                    {copied === `pw-${cred.role}` && (
                      <span className="text-xs" style={{ color: '#4ade80' }}>
                        Copied
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-3 py-2.5">
                  <button
                    onClick={() => onSelect(cred.email, cred.password)}
                    className="flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold transition-all duration-150 hover:scale-105 active:scale-95"
                    style={{
                      background: `${cred.color}18`,
                      color: cred.color,
                      border: `1px solid ${cred.color}30`,
                    }}
                  >
                    <LogIn size={11} />
                    Use
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
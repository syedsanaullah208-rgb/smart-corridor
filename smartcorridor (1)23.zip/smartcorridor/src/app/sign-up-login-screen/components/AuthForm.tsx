'use client';
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Loader2, ArrowRight, AlertCircle } from 'lucide-react';
import { AuthRole, AuthMode } from './AuthLayout';
import { useRouter } from 'next/navigation';

interface LoginFields {
  email: string;
  password: string;
  remember: boolean;
}

interface SignupFields {
  name: string;
  organization: string;
  email: string;
  password: string;
  confirmPassword: string;
  terms: boolean;
}

interface AuthFormProps {
  role: AuthRole;
  mode: AuthMode;
  prefillEmail: string;
  prefillPassword: string;
}

const roleDestinations: Record<AuthRole, string> = {
  admin: '/admin-dashboard',
  hospital: '/admin-dashboard',
  police: '/admin-dashboard',
  citizen: '/',
};

const validCredentials = [
  { role: 'admin', email: 'arjun.chakraborty@eoc.smartcorridor.gov.in', password: 'Admin@SC2026' },
  { role: 'hospital', email: 'dr.priya.mehta@apolloeoc.in', password: 'Hosp@SC2026' },
  { role: 'police', email: 'insp.ravi.kumar@ksp.gov.in', password: 'Police@SC2026' },
  { role: 'citizen', email: 'meera.nair@gmail.com', password: 'Citizen@2026' },
];

export default function AuthForm({ role, mode, prefillEmail, prefillPassword }: AuthFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [authError, setAuthError] = useState('');
  const router = useRouter();

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    watch,
  } = useForm<LoginFields & SignupFields>({ mode: 'onBlur' });

  // Sync prefill from credential table
  useEffect(() => {
    if (prefillEmail) setValue('email', prefillEmail);
    if (prefillPassword) setValue('password', prefillPassword);
  }, [prefillEmail, prefillPassword, setValue]);

  const onSubmitLogin = async (data: LoginFields) => {
    setLoading(true);
    setAuthError('');
    // BACKEND INTEGRATION POINT: POST /api/auth/login with { email, password, role }
    await new Promise((r) => setTimeout(r, 1200));
    const match = validCredentials.find(
      (c) => c.email === data.email && c.password === data.password
    );
    if (!match) {
      setAuthError('Invalid credentials — use the demo accounts below to sign in');
      setLoading(false);
      return;
    }
    setLoading(false);
    router.push(roleDestinations[role]);
  };

  const onSubmitSignup = async (data: SignupFields) => {
    setLoading(true);
    setAuthError('');
    // BACKEND INTEGRATION POINT: POST /api/auth/register with { name, organization, email, password, role }
    await new Promise((r) => setTimeout(r, 1400));
    setLoading(false);
    router.push(roleDestinations[role]);
  };

  if (mode === 'login') {
    return (
      <form onSubmit={handleSubmit(onSubmitLogin as never)} noValidate className="space-y-4">
        {authError && (
          <div
            className="flex items-start gap-3 px-4 py-3 rounded-lg border text-sm"
            style={{
              background: 'rgba(239,68,68,0.08)',
              borderColor: 'rgba(239,68,68,0.25)',
              color: '#fca5a5',
            }}
          >
            <AlertCircle size={16} className="shrink-0 mt-0.5" />
            {authError}
          </div>
        )}

        <div>
          <label
            htmlFor="login-email"
            className="block text-sm font-medium text-foreground mb-1.5"
          >
            Email address
          </label>
          <input
            id="login-email"
            type="email"
            autoComplete="email"
            className="input-field"
            placeholder="your.name@organization.gov.in"
            {...register('email', {
              required: 'Email is required',
              pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email' },
            })}
          />
          {errors.email && (
            <p className="mt-1.5 text-xs" style={{ color: '#fca5a5' }}>
              {errors.email.message}
            </p>
          )}
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label htmlFor="login-password" className="text-sm font-medium text-foreground">
              Password
            </label>
            <button
              type="button"
              className="text-xs transition-colors hover:text-foreground"
              style={{ color: 'var(--accent)' }}
            >
              Forgot password?
            </button>
          </div>
          <div className="relative">
            <input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              className="input-field pr-10"
              placeholder="Enter your password"
              {...register('password', {
                required: 'Password is required',
                minLength: { value: 6, message: 'Password must be at least 6 characters' },
              })}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 transition-colors"
              style={{ color: 'var(--muted-foreground)' }}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.password && (
            <p className="mt-1.5 text-xs" style={{ color: '#fca5a5' }}>
              {errors.password.message}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2">
          <input
            id="remember"
            type="checkbox"
            className="w-4 h-4 rounded accent-primary"
            {...register('remember')}
          />
          <label htmlFor="remember" className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            Keep me signed in for 30 days
          </label>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="btn-primary w-full py-3 text-sm justify-center mt-2"
          style={{ minWidth: '200px' }}
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Authenticating…
            </>
          ) : (
            <>
              Sign In to {role.charAt(0).toUpperCase() + role.slice(1)} Portal
              <ArrowRight size={16} />
            </>
          )}
        </button>
      </form>
    );
  }

  // Signup form
  const password = watch('password');
  return (
    <form onSubmit={handleSubmit(onSubmitSignup as never)} noValidate className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label htmlFor="signup-name" className="block text-sm font-medium text-foreground mb-1.5">
            Full Name
          </label>
          <input
            id="signup-name"
            type="text"
            autoComplete="name"
            className="input-field"
            placeholder="Arjun Chakraborty"
            {...register('name', { required: 'Full name is required' })}
          />
          {errors.name && (
            <p className="mt-1.5 text-xs" style={{ color: '#fca5a5' }}>
              {errors.name.message}
            </p>
          )}
        </div>
        <div>
          <label
            htmlFor="signup-org"
            className="block text-sm font-medium text-foreground mb-1.5"
          >
            Organization
          </label>
          <input
            id="signup-org"
            type="text"
            className="input-field"
            placeholder="City EOC / Hospital name"
            {...register('organization', { required: 'Organization is required' })}
          />
          {errors.organization && (
            <p className="mt-1.5 text-xs" style={{ color: '#fca5a5' }}>
              {errors.organization.message}
            </p>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="signup-email" className="block text-sm font-medium text-foreground mb-1.5">
          Official Email
        </label>
        <input
          id="signup-email"
          type="email"
          autoComplete="email"
          className="input-field"
          placeholder="your.name@organization.gov.in"
          {...register('email', {
            required: 'Email is required',
            pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email' },
          })}
        />
        <p className="mt-1 text-xs" style={{ color: 'var(--muted-foreground)' }}>
          Use your official government or organization email for faster approval.
        </p>
        {errors.email && (
          <p className="mt-1 text-xs" style={{ color: '#fca5a5' }}>
            {errors.email.message}
          </p>
        )}
      </div>

      <div>
        <label
          htmlFor="signup-password"
          className="block text-sm font-medium text-foreground mb-1.5"
        >
          Password
        </label>
        <div className="relative">
          <input
            id="signup-password"
            type={showPassword ? 'text' : 'password'}
            className="input-field pr-10"
            placeholder="Min. 8 characters"
            {...register('password', {
              required: 'Password is required',
              minLength: { value: 8, message: 'Password must be at least 8 characters' },
            })}
          />
          <button
            type="button"
            onClick={() => setShowPassword((s) => !s)}
            className="absolute right-3 top-1/2 -translate-y-1/2"
            style={{ color: 'var(--muted-foreground)' }}
            aria-label={showPassword ? 'Hide password' : 'Show password'}
          >
            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        {errors.password && (
          <p className="mt-1.5 text-xs" style={{ color: '#fca5a5' }}>
            {errors.password.message}
          </p>
        )}
      </div>

      <div>
        <label
          htmlFor="signup-confirm"
          className="block text-sm font-medium text-foreground mb-1.5"
        >
          Confirm Password
        </label>
        <div className="relative">
          <input
            id="signup-confirm"
            type={showConfirm ? 'text' : 'password'}
            className="input-field pr-10"
            placeholder="Re-enter password"
            {...register('confirmPassword', {
              required: 'Please confirm your password',
              validate: (val) => val === password || 'Passwords do not match',
            })}
          />
          <button
            type="button"
            onClick={() => setShowConfirm((s) => !s)}
            className="absolute right-3 top-1/2 -translate-y-1/2"
            style={{ color: 'var(--muted-foreground)' }}
            aria-label={showConfirm ? 'Hide password' : 'Show password'}
          >
            {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        {errors.confirmPassword && (
          <p className="mt-1.5 text-xs" style={{ color: '#fca5a5' }}>
            {errors.confirmPassword.message}
          </p>
        )}
      </div>

      <div className="flex items-start gap-2">
        <input
          id="terms"
          type="checkbox"
          className="w-4 h-4 rounded mt-0.5 accent-primary"
          {...register('terms', { required: 'You must accept the terms' })}
        />
        <label htmlFor="terms" className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
          I agree to the{' '}
          <a href="#" className="underline hover:text-foreground" style={{ color: 'var(--accent)' }}>
            Terms of Service
          </a>{' '}
          and{' '}
          <a href="#" className="underline hover:text-foreground" style={{ color: 'var(--accent)' }}>
            Privacy Policy
          </a>
        </label>
      </div>
      {errors.terms && (
        <p className="text-xs" style={{ color: '#fca5a5' }}>
          {errors.terms.message}
        </p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="btn-primary w-full py-3 text-sm justify-center"
      >
        {loading ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            Submitting request…
          </>
        ) : (
          <>
            Request {role.charAt(0).toUpperCase() + role.slice(1)} Access
            <ArrowRight size={16} />
          </>
        )}
      </button>
    </form>
  );
}
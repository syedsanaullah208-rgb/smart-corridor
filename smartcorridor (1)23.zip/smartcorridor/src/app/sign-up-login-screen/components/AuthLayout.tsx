'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import AuthForm from './AuthForm';
import AuthRoleSelector from './AuthRoleSelector';
import AuthCredentialsTable from './AuthCredentialsTable';
import AuthLeftPanel from './AuthLeftPanel';

export type AuthRole = 'admin' | 'hospital' | 'police' | 'citizen';
export type AuthMode = 'login' | 'signup';

export default function AuthLayout() {
  const [role, setRole] = useState<AuthRole>('admin');
  const [mode, setMode] = useState<AuthMode>('login');
  const [prefillEmail, setPrefillEmail] = useState('');
  const [prefillPassword, setPrefillPassword] = useState('');

  return (
    <div
      className="min-h-screen flex"
      style={{ background: 'var(--background)' }}
    >
      {/* Left panel */}
      <AuthLeftPanel role={role} />

      {/* Right: Form */}
      <div className="flex-1 flex flex-col justify-center items-center px-6 py-12 min-h-screen overflow-y-auto">
        <div className="w-full max-w-md">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 mb-8">
            <AppLogo size={36} />
            <span className="font-bold text-xl text-foreground">SmartCorridor</span>
          </Link>

          {/* Heading */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-foreground mb-1">
              {mode === 'login' ? 'Sign in to your portal' : 'Create your account'}
            </h1>
            <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
              {mode === 'login' ?'Access your role-based emergency dashboard' :'Request access to the SmartCorridor platform'}
            </p>
          </div>

          {/* Role selector */}
          <AuthRoleSelector selected={role} onChange={setRole} />

          {/* Form */}
          <AuthForm
            role={role}
            mode={mode}
            prefillEmail={prefillEmail}
            prefillPassword={prefillPassword}
          />

          {/* Mode toggle */}
          <p className="mt-6 text-sm text-center" style={{ color: 'var(--muted-foreground)' }}>
            {mode === 'login' ? (
              <>
                New to SmartCorridor?{' '}
                <button
                  onClick={() => setMode('signup')}
                  className="font-semibold transition-colors hover:text-foreground"
                  style={{ color: 'var(--accent)' }}
                >
                  Request Access
                </button>
              </>
            ) : (
              <>
                Already have an account?{' '}
                <button
                  onClick={() => setMode('login')}
                  className="font-semibold transition-colors hover:text-foreground"
                  style={{ color: 'var(--accent)' }}
                >
                  Sign In
                </button>
              </>
            )}
          </p>

          {/* Demo credentials */}
          {mode === 'login' && (
            <AuthCredentialsTable
              onSelect={(email, password) => {
                setPrefillEmail(email);
                setPrefillPassword(password);
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
}
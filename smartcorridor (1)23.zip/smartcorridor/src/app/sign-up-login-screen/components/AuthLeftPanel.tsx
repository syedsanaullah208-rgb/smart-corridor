'use client';
import React, { useEffect, useState } from 'react';
import { Navigation2, AlertTriangle, Activity, Shield } from 'lucide-react';
import { AuthRole } from './AuthLayout';
import Icon from '@/components/ui/AppIcon';


const roleContent: Record<AuthRole, { title: string; subtitle: string; color: string; icon: React.ElementType }> = {
  admin: {
    title: 'City-Wide Emergency Command',
    subtitle: 'Monitor all active incidents, corridors, and resources from one dashboard.',
    color: '#ef4444',
    icon: AlertTriangle,
  },
  hospital: {
    title: 'Hospital Resource Management',
    subtitle: 'Track ICU capacity, dispatch ambulances, and receive incoming patient alerts.',
    color: '#3b82f6',
    icon: Activity,
  },
  police: {
    title: 'Traffic & Incident Response',
    subtitle: 'Receive assignments, manage corridor clearance, and log interventions.',
    color: '#f59e0b',
    icon: Shield,
  },
  citizen: {
    title: 'Stay Safe & Informed',
    subtitle: 'Get real-time alerts and alternate routes when emergency corridors activate.',
    color: '#22c55e',
    icon: Navigation2,
  },
};

const liveStats = [
  { id: 'ls-incidents', label: 'Active Incidents', value: '7', trend: '+2 last hour' },
  { id: 'ls-corridors', label: 'Corridors Active', value: '3', trend: '2 critical zones' },
  { id: 'ls-response', label: 'Avg Response', value: '3.8 min', trend: '↓ 0.4 min today' },
  { id: 'ls-icu', label: 'ICU Availability', value: '42%', trend: 'Apollo: 8% critical' },
];

export default function AuthLeftPanel({ role }: { role: AuthRole }) {
  const content = roleContent[role];
  const Icon = content.icon;

  return (
    <div
      className="hidden lg:flex flex-col justify-between w-[480px] xl:w-[560px] shrink-0 p-10 border-r relative overflow-hidden"
      style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
    >
      {/* Background glow */}
      <div
        className="absolute top-0 left-0 right-0 h-80 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at 50% 0%, ${content.color}18 0%, transparent 70%)`,
        }}
      />

      <div className="relative z-10">
        {/* Logo */}
        <div className="flex items-center gap-2 mb-12">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: `${content.color}20`, border: `1px solid ${content.color}40` }}
          >
            <Icon size={20} style={{ color: content.color }} />
          </div>
          <span className="font-bold text-lg text-foreground">SmartCorridor</span>
        </div>

        <h2 className="text-3xl font-bold text-foreground mb-4 leading-tight">{content.title}</h2>
        <p className="text-base leading-relaxed mb-10" style={{ color: 'var(--muted-foreground)' }}>
          {content.subtitle}
        </p>

        {/* Live stats grid */}
        <div className="grid grid-cols-2 gap-3">
          {liveStats.map((stat) => (
            <div
              key={stat.id}
              className="rounded-xl p-4 border"
              style={{ background: 'var(--muted)', borderColor: 'var(--border)' }}
            >
              <p className="text-xs mb-1" style={{ color: 'var(--muted-foreground)' }}>
                {stat.label}
              </p>
              <p className="text-xl font-bold tabular-nums text-foreground">{stat.value}</p>
              <p className="text-xs mt-1" style={{ color: content.color }}>
                {stat.trend}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="relative z-10">
        <div
          className="flex items-center gap-2 text-xs px-3 py-2 rounded-lg"
          style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}
        >
          <span
            className="w-2 h-2 rounded-full pulse-dot shrink-0"
            style={{ background: '#22c55e' }}
          />
          Live data — last updated 13 May 2026, 12:41 IST
        </div>
      </div>
    </div>
  );
}
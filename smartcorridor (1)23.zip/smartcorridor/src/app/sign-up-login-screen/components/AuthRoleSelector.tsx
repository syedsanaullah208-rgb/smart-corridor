'use client';
import React from 'react';
import { LayoutDashboard, Building2, Shield, Users } from 'lucide-react';
import { AuthRole } from './AuthLayout';
import Icon from '@/components/ui/AppIcon';


const roles: { id: AuthRole; label: string; icon: React.ElementType; color: string }[] = [
  { id: 'admin', label: 'Admin', icon: LayoutDashboard, color: '#ef4444' },
  { id: 'hospital', label: 'Hospital', icon: Building2, color: '#3b82f6' },
  { id: 'police', label: 'Police', icon: Shield, color: '#f59e0b' },
  { id: 'citizen', label: 'Citizen', icon: Users, color: '#22c55e' },
];

interface AuthRoleSelectorProps {
  selected: AuthRole;
  onChange: (role: AuthRole) => void;
}

export default function AuthRoleSelector({ selected, onChange }: AuthRoleSelectorProps) {
  return (
    <div className="grid grid-cols-4 gap-2 mb-6">
      {roles.map((role) => {
        const Icon = role.icon;
        const isSelected = selected === role.id;
        return (
          <button
            key={`role-btn-${role.id}`}
            onClick={() => onChange(role.id)}
            className="flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border text-xs font-semibold transition-all duration-150 active:scale-95"
            style={{
              background: isSelected ? `${role.color}15` : 'var(--muted)',
              borderColor: isSelected ? `${role.color}50` : 'var(--border)',
              color: isSelected ? role.color : 'var(--muted-foreground)',
            }}
            aria-pressed={isSelected}
            aria-label={`Select ${role.label} role`}
          >
            <Icon size={18} />
            {role.label}
          </button>
        );
      })}
    </div>
  );
}
'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import { LayoutDashboard, Navigation2, Building2, Shield, Users, BarChart3, Settings, ChevronLeft, ChevronRight, Bell, LogOut, MapPin, Siren,  } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  activeRoute?: string;
}

const navGroups = [
  {
    label: 'Operations',
    items: [
      { label: 'Dashboard', icon: LayoutDashboard, href: '/admin-dashboard', badge: null },
      { label: 'Live Incidents', icon: Siren, href: '/admin-dashboard', badge: '7' },
      { label: 'Corridors', icon: Navigation2, href: '/admin-dashboard', badge: '3' },
      { label: 'Accident Spots', icon: MapPin, href: '/admin-dashboard', badge: null },
    ],
  },
  {
    label: 'Resources',
    items: [
      { label: 'Hospitals', icon: Building2, href: '/admin-dashboard', badge: null },
      { label: 'Police Units', icon: Shield, href: '/admin-dashboard', badge: '2' },
      { label: 'Citizens', icon: Users, href: '/admin-dashboard', badge: null },
    ],
  },
  {
    label: 'Analytics',
    items: [
      { label: 'Reports', icon: BarChart3, href: '/admin-dashboard', badge: null },
      { label: 'Alerts', icon: Bell, href: '/admin-dashboard', badge: '12' },
    ],
  },
];

export default function Sidebar({ collapsed, onToggle, activeRoute }: SidebarProps) {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  return (
    <aside
      className="relative flex flex-col border-r transition-all duration-300 ease-in-out shrink-0"
      style={{
        width: collapsed ? '64px' : '240px',
        background: 'var(--card)',
        borderColor: 'var(--border)',
      }}
    >
      {/* Logo */}
      <div
        className="flex items-center gap-3 px-4 py-4 border-b"
        style={{ borderColor: 'var(--border)', minHeight: '64px' }}
      >
        <div className="shrink-0">
          <AppLogo size={32} />
        </div>
        {!collapsed && (
          <span className="font-bold text-base tracking-tight text-foreground whitespace-nowrap overflow-hidden">
            SmartCorridor
          </span>
        )}
      </div>

      {/* Toggle button */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-16 z-10 flex items-center justify-center w-6 h-6 rounded-full border transition-all duration-150 hover:scale-110"
        style={{
          background: 'var(--card)',
          borderColor: 'var(--border)',
          color: 'var(--muted-foreground)',
        }}
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin py-3 px-2">
        {navGroups.map((group) => (
          <div key={`group-${group.label}`} className="mb-4">
            {!collapsed && (
              <p
                className="px-3 py-1 text-xs font-semibold uppercase tracking-widest mb-1"
                style={{ color: 'var(--muted-foreground)' }}
              >
                {group.label}
              </p>
            )}
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeRoute === item.href;
              return (
                <div
                  key={`nav-${item.label}`}
                  className="relative"
                  onMouseEnter={() => collapsed && setHoveredItem(item.label)}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Link
                    href={item.href}
                    className={`nav-item ${isActive ? 'active' : ''} w-full ${collapsed ? 'justify-center px-2' : ''}`}
                  >
                    <Icon size={18} className="shrink-0" />
                    {!collapsed && (
                      <span className="flex-1 truncate">{item.label}</span>
                    )}
                    {!collapsed && item.badge && (
                      <span
                        className="ml-auto text-xs font-bold px-1.5 py-0.5 rounded-full tabular-nums"
                        style={{
                          background: 'rgba(239,68,68,0.15)',
                          color: '#fca5a5',
                          border: '1px solid rgba(239,68,68,0.3)',
                        }}
                      >
                        {item.badge}
                      </span>
                    )}
                  </Link>
                  {/* Tooltip for collapsed state */}
                  {collapsed && hoveredItem === item.label && (
                    <div
                      className="absolute left-full ml-2 top-1/2 -translate-y-1/2 z-50 px-2 py-1 rounded text-xs font-medium whitespace-nowrap pointer-events-none"
                      style={{ background: 'var(--secondary)', color: 'var(--foreground)', border: '1px solid var(--border)' }}
                    >
                      {item.label}
                      {item.badge && (
                        <span className="ml-1 text-primary">({item.badge})</span>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Bottom: User + Settings */}
      <div className="border-t p-2 space-y-1" style={{ borderColor: 'var(--border)' }}>
        <Link
          href="/admin-dashboard"
          className={`nav-item ${collapsed ? 'justify-center px-2' : ''}`}
        >
          <Settings size={18} className="shrink-0" />
          {!collapsed && <span>Settings</span>}
        </Link>
        <Link
          href="/sign-up-login-screen"
          className={`nav-item ${collapsed ? 'justify-center px-2' : ''}`}
        >
          <LogOut size={18} className="shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </Link>
        {!collapsed && (
          <div
            className="flex items-center gap-3 px-3 py-2 rounded-lg mt-2"
            style={{ background: 'var(--muted)' }}
          >
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
              style={{ background: 'rgba(239,68,68,0.2)', color: '#fca5a5' }}
            >
              AC
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-foreground truncate">Arjun Chakraborty</p>
              <p className="text-xs truncate" style={{ color: 'var(--muted-foreground)' }}>
                Admin · EOC
              </p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
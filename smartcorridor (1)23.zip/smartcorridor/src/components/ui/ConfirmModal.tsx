'use client';
import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmModalProps {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  variant?: 'danger' | 'warning';
}

export default function ConfirmModal({
  open,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  onConfirm,
  onCancel,
  variant = 'danger',
}: ConfirmModalProps) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.7)' }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div
        className="card w-full max-w-md p-6 shadow-2xl"
        style={{ animation: 'fadeInUp 0.15s ease-out' }}
      >
        <div className="flex items-start gap-4">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
            style={{
              background: variant === 'danger' ? 'rgba(239,68,68,0.15)' : 'rgba(245,158,11,0.15)',
            }}
          >
            <AlertTriangle
              size={20}
              style={{ color: variant === 'danger' ? '#fca5a5' : '#fcd34d' }}
            />
          </div>
          <div className="flex-1">
            <h3 id="modal-title" className="text-base font-semibold text-foreground mb-1">
              {title}
            </h3>
            <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
              {description}
            </p>
          </div>
          <button
            onClick={onCancel}
            className="shrink-0 p-1 rounded-md transition-colors hover:bg-muted"
            style={{ color: 'var(--muted-foreground)' }}
            aria-label="Close modal"
          >
            <X size={16} />
          </button>
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button onClick={onCancel} className="btn-secondary">
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            className="btn-primary"
            style={variant === 'warning' ? { background: 'var(--warning)' } : {}}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
import React from 'react';

type BadgeVariant =
  | 'critical' |'high' |'medium' |'low' |'active' |'responding' |'resolved' |'corridor-active' |'corridor-inactive' |'verified' |'reported';

interface StatusBadgeProps {
  variant: BadgeVariant;
  label: string;
  dot?: boolean;
}

const variantMap: Record<BadgeVariant, string> = {
  critical: 'badge-critical',
  high: 'badge-high',
  medium: 'badge-medium',
  low: 'badge-low',
  active: 'badge-active',
  responding: 'badge-responding',
  resolved: 'badge-resolved',
  'corridor-active': 'badge-corridor-active',
  'corridor-inactive': 'badge-corridor-inactive',
  verified: 'badge-responding',
  reported: 'badge-medium',
};

export default function StatusBadge({ variant, label, dot = true }: StatusBadgeProps) {
  return (
    <span className={variantMap[variant]}>
      {dot && (
        <span
          className="inline-block w-1.5 h-1.5 rounded-full"
          style={{ background: 'currentColor' }}
        />
      )}
      {label}
    </span>
  );
}